import {
  InstructionDef,
  InstructionExecutionRecord,
  PipelineSimulationState,
  PipelineStageName,
  BranchStrategy,
  SensorData,
  PerformanceMetrics,
} from '../types';
import { calculateIrrigationDemand } from './irrigationModel';

/**
 * Standard Instruction Sequence for Smart Irrigation Processing
 */
export function getIrrigationInstructionSet(sensor: SensorData): InstructionDef[] {
  const decision = calculateIrrigationDemand(sensor);
  const willBranch = decision.required;

  return [
    {
      id: 'I1',
      pc: 0x1000,
      mnemonic: 'LOAD',
      operands: 'R1, [0x2000]', // Soil Moisture
      type: 'LOAD',
      destReg: 'R1',
      description: `Read Soil Moisture (${sensor.soilMoisture}%) from sensor ADC register [0x2000]`,
    },
    {
      id: 'I2',
      pc: 0x1004,
      mnemonic: 'LOAD',
      operands: 'R2, [0x2004]', // Temperature
      type: 'LOAD',
      destReg: 'R2',
      description: `Read Ambient Temperature (${sensor.temperature}°C) from ADC register [0x2004]`,
    },
    {
      id: 'I3',
      pc: 0x1008,
      mnemonic: 'LOAD',
      operands: 'R3, [0x2008]', // Humidity
      type: 'LOAD',
      destReg: 'R3',
      description: `Read Relative Humidity (${sensor.humidity}%) from ADC register [0x2008]`,
    },
    {
      id: 'I4',
      pc: 0x100C,
      mnemonic: 'SUB',
      operands: 'R4, R_TGT, R1', // Soil Deficit
      type: 'ALU',
      destReg: 'R4',
      srcRegs: ['R1'],
      description: `Compute Soil Deficit: R4 = Target(60%) - SoilMoisture(R1) = ${Math.max(0, 60 - sensor.soilMoisture)}%`,
    },
    {
      id: 'I5',
      pc: 0x1010,
      mnemonic: 'MUL',
      operands: 'R5, R2, R_TCOEFF', // Temp Factor
      type: 'ALU',
      destReg: 'R5',
      srcRegs: ['R2'],
      description: `Booth Multiply: R5 = Temperature(R2) * Evaporation Coefficient(0.60)`,
    },
    {
      id: 'I6',
      pc: 0x1014,
      mnemonic: 'ADD',
      operands: 'R6, R4, R5', // Base + Deficit + Temp
      type: 'ALU',
      destReg: 'R6',
      srcRegs: ['R4', 'R5'],
      description: `Accumulate Water Requirement: R6 = Deficit(R4) + TempFactor(R5)`,
    },
    {
      id: 'I7',
      pc: 0x1018,
      mnemonic: 'SUB',
      operands: 'R6, R6, R3', // Subtract Humidity factor
      type: 'ALU',
      destReg: 'R6',
      srcRegs: ['R6', 'R3'],
      description: `Apply Humidity Dampening: R6 = R6 - HumidityFactor(R3)`,
    },
    {
      id: 'I8',
      pc: 0x101C,
      mnemonic: 'CMP',
      operands: 'R6, #0', // Compare demand > 0
      type: 'ALU',
      srcRegs: ['R6'],
      description: `Compare calculated demand R6 with threshold #0 to determine valve state`,
    },
    {
      id: 'I9',
      pc: 0x1020,
      mnemonic: 'BGT',
      operands: 'R6, IRRIGATION_ACTUATE', // Branch condition
      type: 'BRANCH',
      srcRegs: ['R6'],
      targetAddress: 0x1028,
      branchCondition: () => willBranch,
      description: `Branch on Demand > 0: ${willBranch ? 'TAKEN (Irrigate ON)' : 'NOT TAKEN (Irrigate OFF)'}`,
    },
    {
      id: 'I10',
      pc: 0x1024,
      mnemonic: 'STORE',
      operands: '[0x3000], R6', // Actuate Solenoid Valve
      type: 'STORE',
      srcRegs: ['R6'],
      description: `Write computed flow rate (${decision.waterFlowRate} L/min) to Solenoid Valve IO register [0x3000]`,
    },
    {
      id: 'I11',
      pc: 0x1028,
      mnemonic: 'STORE',
      operands: '[0x3004], R7', // Telemetry log
      type: 'STORE',
      srcRegs: ['R7'],
      description: `Write system telemetry status and execution timestamp to Memory Log [0x3004]`,
    },
  ];
}

/**
 * Precomputes cycle-by-cycle execution table for the instruction set given configuration
 */
export function simulateFullPipeline(
  sensor: SensorData,
  forwardingEnabled: boolean = true,
  branchStrategy: BranchStrategy = 'dynamic-2bit',
  structuralHazardSim: boolean = false
): {
  records: InstructionExecutionRecord[];
  totalCycles: number;
  hazards: Array<{
    cycle: number;
    type: 'Data (RAW)' | 'Load-Use Data' | 'Structural (Memory Bus)' | 'Control (Branch)';
    instructionId: string;
    description: string;
    action: string;
    stalls: number;
  }>;
  forwardingEvents: Array<{
    cycle: number;
    fromStage: 'EX/MEM' | 'MEM/WB';
    toStage: 'EX';
    register: string;
    fromInst: string;
    toInst: string;
  }>;
  totalStalls: number;
  totalFlushes: number;
  branchAccuracy: { total: number; correct: number; incorrect: number };
} {
  const instructions = getIrrigationInstructionSet(sensor);
  const decision = calculateIrrigationDemand(sensor);
  const branchTaken = decision.required;

  // Let's determine branch prediction outcome
  let predictedTaken = false;
  if (branchStrategy === 'always-taken') predictedTaken = true;
  else if (branchStrategy === 'always-not-taken') predictedTaken = false;
  else if (branchStrategy === 'dynamic-2bit' || branchStrategy === 'dynamic-1bit') {
    // Dynamic history based on typical drought/dry sensor input
    predictedTaken = sensor.soilMoisture < 50;
  }

  const isMisprediction = predictedTaken !== branchTaken;

  const records: InstructionExecutionRecord[] = instructions.map((inst) => ({
    instructionId: inst.id,
    mnemonic: inst.mnemonic,
    operands: inst.operands,
    stageHistory: {},
    startCycle: 1,
  }));

  const hazards: Array<{
    cycle: number;
    type: 'Data (RAW)' | 'Load-Use Data' | 'Structural (Memory Bus)' | 'Control (Branch)';
    instructionId: string;
    description: string;
    action: string;
    stalls: number;
  }> = [];

  const forwardingEvents: Array<{
    cycle: number;
    fromStage: 'EX/MEM' | 'MEM/WB';
    toStage: 'EX';
    register: string;
    fromInst: string;
    toInst: string;
  }> = [];

  let cycle = 1;
  let totalStalls = 0;
  let totalFlushes = 0;

  // Track each instruction's current stage index (0=IF, 1=ID, 2=EX, 3=MEM, 4=WB, 5=DONE)
  const stages: PipelineStageName[] = ['IF', 'ID', 'EX', 'MEM', 'WB'];
  const instProgress = instructions.map(() => -1); // -1 = not fetched yet
  const instStallRemaining = instructions.map(() => 0);
  const isFlushed = instructions.map(() => false);

  let nextInstToFetch = 0;

  while (instProgress.some((p) => p < 5 && p !== -2) && cycle <= 35) {
    // Check if any instruction completed WB in previous cycle
    // Process from oldest instruction (WB) down to newest (IF) to handle hazards
    
    // Check structural hazard simulation if enabled (Single Memory Port contention between IF and MEM)
    let memoryPortBusyByMemStage = false;
    for (let i = 0; i < instructions.length; i++) {
      if (instProgress[i] === 3 && (instructions[i].type === 'LOAD' || instructions[i].type === 'STORE')) {
        memoryPortBusyByMemStage = true;
        break;
      }
    }

    // Advance stages from WB backwards
    for (let i = 0; i < instructions.length; i++) {
      if (isFlushed[i]) {
        if (records[i].stageHistory[cycle] === undefined && instProgress[i] >= 0 && instProgress[i] < 5) {
          records[i].stageHistory[cycle] = 'FLUSH';
        }
        continue;
      }

      const p = instProgress[i];
      if (p === -1) continue; // Not fetched yet

      if (instStallRemaining[i] > 0) {
        records[i].stageHistory[cycle] = 'STALL';
        instStallRemaining[i]--;
        continue;
      }

      if (p >= 0 && p < 5) {
        records[i].stageHistory[cycle] = stages[p];
      }
    }

    // Check Data Hazards in ID stage for instructions about to enter EX
    for (let i = 0; i < instructions.length; i++) {
      if (instProgress[i] === 1 && !isFlushed[i] && instStallRemaining[i] === 0) {
        const currInst = instructions[i];
        const neededRegs = currInst.srcRegs || [];

        for (const reg of neededRegs) {
          // Check prior instructions still in pipeline
          for (let j = 0; j < i; j++) {
            if (isFlushed[j]) continue;
            const prevInst = instructions[j];
            const prevStage = instProgress[j];

            if (prevInst.destReg === reg && prevStage < 5 && prevStage >= 2) {
              // Hazard detected!
              if (forwardingEnabled) {
                if (prevInst.type === 'LOAD' && prevStage === 2) {
                  // LOAD-USE Hazard: Data is only available after MEM stage (prevStage 3)
                  // 1-cycle stall required even with forwarding
                  instStallRemaining[i] = 1;
                  totalStalls++;
                  hazards.push({
                    cycle,
                    type: 'Load-Use Data',
                    instructionId: currInst.id,
                    description: `Load-Use hazard on ${reg} between ${prevInst.id} (${prevInst.mnemonic}) and ${currInst.id} (${currInst.mnemonic})`,
                    action: 'Inserted 1-cycle stall bubble. Forwarded from MEM/WB -> EX on next cycle.',
                    stalls: 1,
                  });
                  forwardingEvents.push({
                    cycle: cycle + 1,
                    fromStage: 'MEM/WB',
                    toStage: 'EX',
                    register: reg,
                    fromInst: prevInst.id,
                    toInst: currInst.id,
                  });
                } else if (prevStage === 2) {
                  // ALU-ALU Forwarding EX/MEM -> EX (0 stalls!)
                  forwardingEvents.push({
                    cycle,
                    fromStage: 'EX/MEM',
                    toStage: 'EX',
                    register: reg,
                    fromInst: prevInst.id,
                    toInst: currInst.id,
                  });
                  hazards.push({
                    cycle,
                    type: 'Data (RAW)',
                    instructionId: currInst.id,
                    description: `RAW hazard on ${reg} (${prevInst.id} -> ${currInst.id}) resolved via EX/MEM ➔ EX bypass forwarding`,
                    action: 'Forwarded directly from EX/MEM register. 0 stall cycles.',
                    stalls: 0,
                  });
                } else if (prevStage === 3) {
                  // MEM/WB -> EX forwarding (0 stalls)
                  forwardingEvents.push({
                    cycle,
                    fromStage: 'MEM/WB',
                    toStage: 'EX',
                    register: reg,
                    fromInst: prevInst.id,
                    toInst: currInst.id,
                  });
                }
              } else {
                // No Forwarding: Must stall until prevInst finishes WB (prevStage 4)
                const distanceToWB = 4 - prevStage;
                if (distanceToWB > 0) {
                  instStallRemaining[i] = distanceToWB;
                  totalStalls += distanceToWB;
                  hazards.push({
                    cycle,
                    type: 'Data (RAW)',
                    instructionId: currInst.id,
                    description: `RAW Data Hazard on ${reg} (${prevInst.id} -> ${currInst.id}) without Forwarding`,
                    action: `Hardware stalled for ${distanceToWB} cycle(s) until ${prevInst.id} reaches WB stage.`,
                    stalls: distanceToWB,
                  });
                }
              }
            }
          }
        }
      }
    }

    // Check Control Hazard for Branch (I9)
    const branchInstIdx = instructions.findIndex((inst) => inst.type === 'BRANCH');
    if (branchInstIdx !== -1 && instProgress[branchInstIdx] === 2) {
      // Branch is evaluated in EX stage
      if (isMisprediction) {
        // Speculatively fetched instructions behind branch must be FLUSHED
        totalFlushes += 2;
        hazards.push({
          cycle,
          type: 'Control (Branch)',
          instructionId: instructions[branchInstIdx].id,
          description: `Branch Misprediction detected in EX stage! Predicted: ${predictedTaken ? 'TAKEN' : 'NOT TAKEN'}, Actual: ${branchTaken ? 'TAKEN' : 'NOT TAKEN'}`,
          action: 'Flushed 2 speculatively fetched pipeline stages. Inserted NOPs, updated Branch Target Address.',
          stalls: 2,
        });

        // Flush younger instructions in IF/ID
        for (let k = branchInstIdx + 1; k < instructions.length && k <= branchInstIdx + 2; k++) {
          if (instProgress[k] >= 0 && instProgress[k] < 3) {
            isFlushed[k] = true;
          }
        }
      }
    }

    // Advance progress for all instructions that are not stalled
    for (let i = instructions.length - 1; i >= 0; i--) {
      if (instProgress[i] >= 0 && instProgress[i] < 5 && !isFlushed[i]) {
        if (instStallRemaining[i] === 0) {
          instProgress[i]++;
        }
      }
    }

    // Try to fetch next instruction into IF if IF stage is free and no structural hazard
    if (nextInstToFetch < instructions.length) {
      const structuralConflict = structuralHazardSim && memoryPortBusyByMemStage;
      if (structuralConflict) {
        hazards.push({
          cycle,
          type: 'Structural (Memory Bus)',
          instructionId: instructions[nextInstToFetch].id,
          description: `Unified Memory Bus collision: IF stage trying to fetch ${instructions[nextInstToFetch].id} while MEM stage is reading sensor memory`,
          action: 'IF stage stalled for 1 cycle. Split Harvard Cache recommended to prevent memory contention.',
          stalls: 1,
        });
        totalStalls++;
      } else {
        // Fetch instruction
        instProgress[nextInstToFetch] = 0; // IF stage
        records[nextInstToFetch].startCycle = cycle;
        nextInstToFetch++;
      }
    }

    cycle++;
  }

  const branchAccuracy = {
    total: 1,
    correct: isMisprediction ? 0 : 1,
    incorrect: isMisprediction ? 1 : 0,
  };

  return {
    records,
    totalCycles: cycle - 1,
    hazards,
    forwardingEvents,
    totalStalls,
    totalFlushes,
    branchAccuracy,
  };
}

/**
 * Calculates comparative Performance Metrics (Unoptimized vs Optimized)
 */
export function calculatePerformanceMetrics(sensor: SensorData): PerformanceMetrics {
  // 1. Unoptimized simulation (No forwarding, Always Not-Taken branch, Structural contention enabled)
  const unoptimized = simulateFullPipeline(sensor, false, 'always-not-taken', true);
  
  // 2. Optimized simulation (Full Forwarding, 2-bit Dynamic Branch Prediction, Harvard Split Cache)
  const optimized = simulateFullPipeline(sensor, true, 'dynamic-2bit', false);

  const ic = getIrrigationInstructionSet(sensor).length; // 11 instructions

  const unoptCPI = Number((unoptimized.totalCycles / ic).toFixed(2));
  const optCPI = Number((optimized.totalCycles / ic).toFixed(2));

  const unoptThroughput = Number((ic / unoptimized.totalCycles).toFixed(3));
  const optThroughput = Number((ic / optimized.totalCycles).toFixed(3));

  const speedup = Number((unoptimized.totalCycles / optimized.totalCycles).toFixed(2));
  
  const originalStalls = Math.max(1, unoptimized.totalStalls + unoptimized.totalFlushes);
  const optStalls = optimized.totalStalls + optimized.totalFlushes;
  const stallReductionPercent = Number(
    Math.max(0, ((originalStalls - optStalls) / originalStalls) * 100).toFixed(1)
  );

  // CPU clock frequency baseline = 50 MHz (20ns cycle time)
  const clockPeriodNs = 20;
  const unoptLatency = unoptimized.totalCycles * clockPeriodNs;
  const optLatency = optimized.totalCycles * clockPeriodNs;

  // Processor dynamic power reduction ~ proportional to reduced idle/stall cycles & execution time
  const estimatedCpuEnergySavedPct = Number(
    Math.min(65, Math.max(10, ((unoptimized.totalCycles - optimized.totalCycles) / unoptimized.totalCycles) * 100 * 0.85)).toFixed(1)
  );

  return {
    instructionCount: ic,
    unoptimizedCycles: unoptimized.totalCycles,
    optimizedCycles: optimized.totalCycles,
    unoptimizedStalls: unoptimized.totalStalls + unoptimized.totalFlushes,
    optimizedStalls: optimized.totalStalls + optimized.totalFlushes,
    unoptimizedCPI: unoptCPI,
    optimizedCPI: optCPI,
    unoptimizedThroughput: unoptThroughput,
    optimizedThroughput: optThroughput,
    unoptimizedLatency: unoptLatency,
    optimizedLatency: optLatency,
    speedup,
    stallReductionPercent,
    estimatedCpuEnergySavedPct,
  };
}
