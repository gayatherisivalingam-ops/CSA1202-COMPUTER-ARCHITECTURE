import React, { useState } from 'react';
import {
  Activity,
  Cpu,
  Droplet,
  Zap,
  Clock,
  RotateCcw,
  Play,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  HelpCircle,
  Flame,
  Info,
  Waves,
  Sparkles,
  Layers,
  CheckCircle2,
  Share2,
} from 'lucide-react';
import { SensorData, IrrigationDecision, PerformanceMetrics } from '../../types';
import { SensorCard } from '../common/SensorCard';
import { MetricCard } from '../common/MetricCard';
import { STAGE_CONFIG } from '../common/PipelineStageBadge';
import { getMoistureStatus, getTemperatureStatus, getHumidityStatus } from '../../utils/irrigationModel';
import { analyzeIEEE754 } from '../../utils/arithmeticEngine';

interface DashboardViewProps {
  sensor: SensorData;
  setSensor: React.Dispatch<React.SetStateAction<SensorData>>;
  decision: IrrigationDecision;
  metrics: PerformanceMetrics;
  setActiveTab: (tab: string) => void;
  onRunSimulation: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  sensor,
  setSensor,
  decision,
  metrics,
  setActiveTab,
  onRunSimulation,
}) => {
  const [selectedStage, setSelectedStage] = useState<'IF' | 'ID' | 'EX' | 'MEM' | 'WB'>('EX');
  const moistureStatus = getMoistureStatus(sensor.soilMoisture);
  const tempStatus = getTemperatureStatus(sensor.temperature);
  const humidityStatus = getHumidityStatus(sensor.humidity);

  const ieeeData = analyzeIEEE754(sensor.temperature);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Top Banner / Breadcrumb */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-mono font-bold">
              CSA1202 // HIGH DENSITY ARCH
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-mono">
              5-STAGE PIPELINED SIMULATOR
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight">
            Precision Agriculture Computer Architecture Datapath
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time execution of soil moisture, temperature, and humidity sensors through 5-stage RISC ALU & branch prediction logic.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onRunSimulation}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded shadow-xs transition flex items-center gap-1.5 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Run Simulation
          </button>
          <button
            onClick={() => setActiveTab('pipeline')}
            className="px-3.5 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded transition flex items-center gap-1.5 cursor-pointer"
          >
            <Cpu className="w-3.5 h-3.5 text-emerald-600" />
            Explore Datapath
          </button>
        </div>
      </div>

      {/* Main Grid: 8 Cols Datapath / Sensors + 4 Cols Decisions / Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column (8 cols): 3 Sensors + 5-Stage Visualizer */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          {/* 3 Live Sensor Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <SensorCard
              type="moisture"
              value={sensor.soilMoisture}
              unit="%"
              status={moistureStatus}
              min={0}
              max={100}
              onChange={(val) => setSensor((prev) => ({ ...prev, soilMoisture: val }))}
              interactive={true}
            />
            <SensorCard
              type="temperature"
              value={sensor.temperature}
              unit="°C"
              status={tempStatus}
              min={0}
              max={50}
              onChange={(val) => setSensor((prev) => ({ ...prev, temperature: val }))}
              interactive={true}
            />
            <SensorCard
              type="humidity"
              value={sensor.humidity}
              unit="%"
              status={humidityStatus}
              min={0}
              max={100}
              onChange={(val) => setSensor((prev) => ({ ...prev, humidity: val }))}
              interactive={true}
            />
          </div>

          {/* 5-Stage Pipelined Datapath Execution Visualizer */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col p-4 sm:p-5">
            <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  5-Stage Pipelined Datapath Execution
                </h3>
                <p className="text-[11px] text-slate-400">
                  Instruction flow through IF, ID, EX, MEM, and WB registers
                </p>
              </div>
              <div className="flex items-center gap-2 text-[10px]">
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-bold font-mono">
                  CYCLES: {metrics.optimizedCycles}
                </span>
                <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded font-bold font-mono">
                  MODE: FORWARDING ON
                </span>
              </div>
            </div>

            {/* 5 Stage Blocks */}
            <div className="relative py-4 my-1 overflow-x-auto">
              <div className="min-w-[560px] flex items-center justify-between relative px-2">
                <div className="absolute top-1/2 left-4 right-4 h-1 bg-slate-100 -translate-y-1/2 z-0" />

                {/* IF */}
                <div
                  onClick={() => setSelectedStage('IF')}
                  className={`z-10 w-24 h-28 bg-emerald-50 border-2 rounded-lg flex flex-col items-center justify-center p-2 shadow-xs cursor-pointer transition ${
                    selectedStage === 'IF' ? 'border-emerald-600 ring-2 ring-emerald-400' : 'border-emerald-500'
                  }`}
                >
                  <span className="text-[10px] font-bold text-emerald-800 mb-1.5">IF</span>
                  <div className="w-full h-10 bg-white border border-emerald-200 rounded flex items-center justify-center text-[9px] text-center font-mono leading-none px-1 text-slate-800">
                    LD R1, S_MOIST
                  </div>
                  <span className="text-[9px] mt-1.5 text-emerald-700 uppercase font-bold">Fetch</span>
                </div>

                {/* ID */}
                <div className="relative z-10 flex flex-col items-center">
                  <div className="absolute -top-6 text-[9px] text-orange-700 font-bold bg-orange-50 px-1.5 py-0.5 rounded border border-orange-300">
                    FORWARD R1
                  </div>
                  <div
                    onClick={() => setSelectedStage('ID')}
                    className={`w-24 h-28 bg-blue-50 border-2 rounded-lg flex flex-col items-center justify-center p-2 shadow-xs cursor-pointer transition ${
                      selectedStage === 'ID' ? 'border-blue-600 ring-2 ring-blue-400' : 'border-blue-500'
                    }`}
                  >
                    <span className="text-[10px] font-bold text-blue-800 mb-1.5">ID</span>
                    <div className="w-full h-10 bg-white border border-blue-200 rounded flex items-center justify-center text-[9px] text-center font-mono leading-none px-1 text-slate-800">
                      ADD R2, R1, #0
                    </div>
                    <span className="text-[9px] mt-1.5 text-blue-700 uppercase font-bold">Decode</span>
                  </div>
                </div>

                {/* EX */}
                <div
                  onClick={() => setSelectedStage('EX')}
                  className={`z-10 w-24 h-28 bg-purple-50 border-2 rounded-lg flex flex-col items-center justify-center p-2 shadow-xs cursor-pointer transition ${
                    selectedStage === 'EX' ? 'border-purple-600 ring-2 ring-purple-400' : 'border-purple-500'
                  }`}
                >
                  <span className="text-[10px] font-bold text-purple-800 mb-1.5">EX</span>
                  <div className="w-full h-10 bg-white border border-purple-200 rounded flex items-center justify-center text-[9px] text-center font-mono leading-none px-1 text-slate-800">
                    MUL R3, R2, K_W
                  </div>
                  <span className="text-[9px] mt-1.5 text-purple-700 uppercase font-bold">ALU</span>
                </div>

                {/* MEM */}
                <div
                  onClick={() => setSelectedStage('MEM')}
                  className={`z-10 w-24 h-28 bg-amber-50 border-2 rounded-lg flex flex-col items-center justify-center p-2 shadow-xs cursor-pointer transition ${
                    selectedStage === 'MEM' ? 'border-amber-600 ring-2 ring-amber-400' : 'border-amber-500'
                  }`}
                >
                  <span className="text-[10px] font-bold text-amber-800 mb-1.5">MEM</span>
                  <div className="w-full h-10 bg-white border border-amber-200 rounded flex items-center justify-center text-[9px] text-center font-mono leading-none px-1 text-slate-800">
                    SW R3, IRRIG_V
                  </div>
                  <span className="text-[9px] mt-1.5 text-amber-700 uppercase font-bold">RAM</span>
                </div>

                {/* WB */}
                <div
                  onClick={() => setSelectedStage('WB')}
                  className={`z-10 w-24 h-28 bg-slate-50 border-2 rounded-lg flex flex-col items-center justify-center p-2 shadow-xs cursor-pointer transition ${
                    selectedStage === 'WB' ? 'border-slate-500 ring-2 ring-slate-400' : 'border-slate-400'
                  }`}
                >
                  <span className="text-[10px] font-bold text-slate-700 mb-1.5">WB</span>
                  <div className="w-full h-10 bg-white border border-slate-200 rounded flex items-center justify-center text-[9px] text-center font-mono leading-none px-1 text-slate-600 uppercase italic">
                    NOP
                  </div>
                  <span className="text-[9px] mt-1.5 text-slate-500 uppercase font-bold">Reg</span>
                </div>
              </div>
            </div>

            {/* Sub-cards in Datapath Container */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-100">
              {/* Active Hazard Analysis */}
              <div className="bg-slate-50 rounded-lg p-3.5 border border-slate-200">
                <div className="flex items-center justify-between mb-2.5">
                  <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Active Hazard Analysis
                  </h4>
                  <span className="text-[9px] font-mono text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded font-semibold">
                    0 BUBBLES
                  </span>
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="font-mono text-slate-700">RAW (Data Hazard)</span>
                    <span className="text-emerald-700 font-bold uppercase">Resolved (Forwarded)</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="font-mono text-slate-500">Structural Conflict</span>
                    <span className="text-slate-500 font-bold uppercase">None (Harvard Bus)</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="font-mono text-slate-500">Branch Mispredict</span>
                    <span className="text-slate-500 font-bold uppercase">None (2-Bit FSM)</span>
                  </div>
                </div>
              </div>

              {/* Arithmetic Unit // IEEE 754 */}
              <div className="bg-slate-50 rounded-lg p-3.5 border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Arithmetic Unit // IEEE 754
                  </h4>
                  <span className="text-[9px] font-mono text-slate-600 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                    FP32 Converter
                  </span>
                </div>
                <div className="font-mono text-[9px] grid grid-cols-12 gap-0.5">
                  <div className="col-span-1 bg-red-100 border border-red-200 text-red-700 text-center py-1 font-bold">
                    {ieeeData.signBit}
                  </div>
                  <div className="col-span-3 bg-blue-100 border border-blue-200 text-blue-700 text-center py-1 font-bold truncate">
                    {ieeeData.exponentBits}
                  </div>
                  <div className="col-span-8 bg-emerald-100 border border-emerald-200 text-emerald-700 text-center py-1 font-bold truncate">
                    {ieeeData.mantissaBits.slice(0, 16)}...
                  </div>
                </div>
                <div className="mt-2 flex justify-between text-[10px]">
                  <span className="text-slate-500">Input: {sensor.temperature}°C</span>
                  <span className="text-slate-700 font-bold font-mono">Hex: {ieeeData.hex}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Irrigation Decision + Performance */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {/* Irrigation Decision Card */}
          <div
            id="irrigation-recommendation-card"
            className={`rounded-xl p-5 text-white shadow-md relative overflow-hidden flex flex-col justify-between ${
              decision.required ? 'bg-[#1B4332]' : 'bg-slate-800'
            }`}
          >
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-emerald-300 uppercase tracking-widest flex items-center gap-1.5">
                  <Droplet className="w-3.5 h-3.5" />
                  Irrigation Decision
                </h3>
                <span
                  className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${
                    decision.required ? 'bg-emerald-500/30 text-emerald-200 border border-emerald-400/40' : 'bg-slate-700 text-slate-300'
                  }`}
                >
                  {decision.required ? 'ACTUATOR ACTIVE' : 'IDLE'}
                </span>
              </div>

              <div className="text-3xl sm:text-4xl font-black mb-1 tracking-tight">
                {decision.required ? 'VALVE ON' : 'VALVE OFF'}
              </div>

              <div className="text-xs text-emerald-100/80">
                Flow Rate: <span className="font-mono font-bold text-white text-sm">{decision.waterFlowRate} L/min</span>
              </div>

              <div className="mt-4 pt-4 border-t border-emerald-700/60 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="opacity-75">Priority Level</span>
                  <span
                    className={`px-2 py-0.5 rounded font-bold text-[9px] ${
                      decision.priority === 'CRITICAL'
                        ? 'bg-red-500 text-white'
                        : decision.priority === 'HIGH'
                        ? 'bg-amber-500 text-white'
                        : 'bg-emerald-600 text-white'
                    }`}
                  >
                    {decision.priority}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="opacity-75">Decision Latency</span>
                  <span className="font-mono text-emerald-200 font-bold">
                    {metrics.optimizedLatency} ns
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="opacity-75">Est. Water Demand</span>
                  <span className="font-mono text-white font-bold">{decision.waterAmountLiters} L</span>
                </div>
              </div>
            </div>
            <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-emerald-400/10 rounded-full blur-2xl"></div>
          </div>

          {/* Pipeline Performance Card */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4 sm:p-5 flex flex-col justify-between flex-1">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                  Pipeline Performance
                </h3>
                <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {metrics.speedup}x GAIN
                </span>
              </div>

              <div className="space-y-3.5 mb-4">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-600 font-medium">Cycles Per Instruction (CPI)</span>
                    <span className="font-bold text-emerald-700 font-mono">{metrics.optimizedCPI}</span>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full w-[85%] rounded-full"></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-600 font-medium">Speedup (Pipelined)</span>
                    <span className="font-bold text-blue-700 font-mono">{metrics.speedup}x</span>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-blue-500 h-full w-[78%] rounded-full"></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-600 font-medium">Throughput (Instr/Cycle)</span>
                    <span className="font-bold text-purple-700 font-mono">{metrics.optimizedThroughput}</span>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-purple-500 h-full w-[65%] rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Optimization Impact & SDG */}
            <div className="space-y-2 mt-auto">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div className="text-[10px] font-bold text-slate-400 uppercase mb-2">
                  Optimization Impact
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="text-center p-1.5 bg-white rounded border border-slate-200">
                    <div className="text-lg font-bold text-slate-800">-{metrics.stallReductionPercent}%</div>
                    <div className="text-[9px] text-slate-500 uppercase">Stall Reduction</div>
                  </div>
                  <div className="text-center p-1.5 bg-white rounded border border-slate-200">
                    <div className="text-lg font-bold text-emerald-700">92%</div>
                    <div className="text-[9px] text-slate-500 uppercase">Branch Accuracy</div>
                  </div>
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-100 flex items-center gap-2.5">
                <div className="w-8 h-8 rounded bg-white flex items-center justify-center shrink-0 border border-emerald-200 text-emerald-700 font-bold text-xs">
                  SDG 2
                </div>
                <div>
                  <div className="text-[11px] font-bold text-emerald-900 leading-tight">Zero Hunger & Clean Water</div>
                  <div className="text-[9px] text-emerald-700 leading-tight">Precision computing optimizing resource distribution.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 6 Key Performance Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <MetricCard
          id="metric-cpi"
          title="CPI"
          value={metrics.optimizedCPI}
          subValue={`vs ${metrics.unoptimizedCPI}`}
          badge="Cycles/Inst"
          icon={Activity}
          color="emerald"
          description="Ideal CPI = 1.0"
        />
        <MetricCard
          id="metric-cycles"
          title="Total Cycles"
          value={metrics.optimizedCycles}
          subValue="Cycles"
          badge="Optimized"
          icon={Clock}
          color="teal"
          description={`${metrics.unoptimizedCycles} unoptimized`}
        />
        <MetricCard
          id="metric-throughput"
          title="Throughput"
          value={metrics.optimizedThroughput}
          subValue="IPC"
          badge="Inst/Cycle"
          icon={TrendingUp}
          color="blue"
          description="Instructions / Cycle"
        />
        <MetricCard
          id="metric-latency"
          title="Latency"
          value={`${metrics.optimizedLatency}`}
          subValue="ns"
          badge="@ 50MHz"
          icon={Zap}
          color="purple"
          description={`${metrics.unoptimizedLatency - metrics.optimizedLatency}ns faster`}
        />
        <MetricCard
          id="metric-speedup"
          title="Speedup"
          value={`${metrics.speedup}x`}
          subValue="Faster"
          badge="Amdahl Gain"
          icon={Sparkles}
          color="amber"
          description="Unopt / Opt runtime"
        />
        <MetricCard
          id="metric-stalls"
          title="Stall Cycles"
          value={metrics.optimizedStalls}
          subValue={`-${metrics.stallReductionPercent}%`}
          badge="Reduced"
          icon={Layers}
          color="rose"
          description={`${metrics.unoptimizedStalls} without bypass`}
        />
      </div>

      {/* Navigation Quick Jump Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        <div
          onClick={() => setActiveTab('arithmetic')}
          className="p-4 rounded-xl bg-white border border-slate-200 hover:border-emerald-500 shadow-xs transition cursor-pointer group"
        >
          <h4 className="text-xs font-bold text-slate-800 group-hover:text-emerald-700 transition flex items-center justify-between">
            <span>Booth's Multiplication & IEEE 754</span>
            <ArrowRight className="w-3.5 h-3.5 text-emerald-600 group-hover:translate-x-1 transition-transform" />
          </h4>
          <p className="text-[11px] text-slate-500 mt-1">
            Walk through step-by-step 2's complement multiplication, restoring division, and 32-bit floating point sensor registers.
          </p>
        </div>

        <div
          onClick={() => setActiveTab('hazards')}
          className="p-4 rounded-xl bg-white border border-slate-200 hover:border-emerald-500 shadow-xs transition cursor-pointer group"
        >
          <h4 className="text-xs font-bold text-slate-800 group-hover:text-emerald-700 transition flex items-center justify-between">
            <span>Hazard Detection & Forwarding</span>
            <ArrowRight className="w-3.5 h-3.5 text-emerald-600 group-hover:translate-x-1 transition-transform" />
          </h4>
          <p className="text-[11px] text-slate-500 mt-1">
            Observe RAW dependencies, EX/MEM forwarding paths, structural bus sharing, and branch misprediction flushes.
          </p>
        </div>

        <div
          onClick={() => setActiveTab('branch')}
          className="p-4 rounded-xl bg-white border border-slate-200 hover:border-emerald-500 shadow-xs transition cursor-pointer group sm:col-span-2 lg:col-span-1"
        >
          <h4 className="text-xs font-bold text-slate-800 group-hover:text-emerald-700 transition flex items-center justify-between">
            <span>Branch Prediction & 2-Bit FSM</span>
            <ArrowRight className="w-3.5 h-3.5 text-emerald-600 group-hover:translate-x-1 transition-transform" />
          </h4>
          <p className="text-[11px] text-slate-500 mt-1">
            Compare 2-bit saturating counter against static schemes across diurnal irrigation decision cycles.
          </p>
        </div>
      </div>
    </div>
  );
};

