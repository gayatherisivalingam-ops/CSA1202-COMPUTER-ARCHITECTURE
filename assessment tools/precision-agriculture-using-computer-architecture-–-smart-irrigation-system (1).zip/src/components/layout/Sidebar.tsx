import React from 'react';
import {
  LayoutDashboard,
  Sliders,
  Binary,
  GitCommit,
  ShieldAlert,
  GitFork,
  Gauge,
  Code2,
  FileCheck2,
  Info,
  ChevronRight,
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

export const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, tag: 'Live' },
  { id: 'sensors', label: 'Sensor Input', icon: Sliders, tag: 'Interactive' },
  { id: 'arithmetic', label: 'Arithmetic Processing', icon: Binary, tag: 'Booth & IEEE' },
  { id: 'pipeline', label: 'Pipeline Datapath', icon: GitCommit, tag: '5-Stage' },
  { id: 'hazards', label: 'Hazard Analysis', icon: ShieldAlert, tag: 'Data & Struct' },
  { id: 'branch', label: 'Branch Prediction', icon: GitFork, tag: '2-Bit FSM' },
  { id: 'performance', label: 'Performance Evaluation', icon: Gauge, tag: 'CPI & Speedup' },
  { id: 'pseudocode', label: 'Pseudocode', icon: Code2, tag: 'ISA' },
  { id: 'results', label: 'Results & Export', icon: FileCheck2, tag: 'CSV/JSON' },
  { id: 'about', label: 'About Project', icon: Info, tag: 'CO2/CO3' },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpen,
  setIsOpen,
}) => {
  return (
    <aside
      className={`fixed lg:sticky top-0 lg:top-[57px] left-0 z-40 h-full lg:h-[calc(100vh-57px)] w-64 bg-[#1B4332] flex flex-col border-r border-emerald-800 text-white shrink-0 transition-transform duration-300 ${
        isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}
    >
      {/* Sidebar Header */}
      <div className="p-4 sm:p-5 border-b border-emerald-700/80 shrink-0">
        <h1 className="text-sm font-bold leading-tight uppercase tracking-tight text-white flex items-center justify-between">
          <span>Precision Agriculture</span>
        </h1>
        <p className="text-[10px] text-emerald-400 font-mono mt-0.5">v2.0 // CSA1202-ARCH</p>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 py-3 overflow-y-auto space-y-1">
        <div className="px-4 py-1 text-[10px] uppercase font-bold tracking-wider text-emerald-400/80">
          Architecture Views
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              id={`nav-link-${item.id}`}
              onClick={() => {
                setActiveTab(item.id);
                if (window.innerWidth < 1024) setIsOpen(false);
              }}
              className={`w-full text-left px-4 py-2 flex items-center justify-between transition-colors text-xs cursor-pointer ${
                isActive
                  ? 'bg-emerald-800/60 border-l-4 border-emerald-400 text-white font-bold'
                  : 'hover:bg-emerald-800/30 text-emerald-100/70 hover:text-white opacity-85 hover:opacity-100 border-l-4 border-transparent'
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full shrink-0 transition-colors ${
                    isActive ? 'bg-emerald-400 shadow-sm shadow-emerald-400' : 'bg-emerald-700'
                  }`}
                />
                <div className="flex items-center gap-2">
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-300' : 'text-emerald-400/70'}`} />
                  <span>{item.label}</span>
                </div>
              </div>

              <span
                className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-medium ${
                  isActive
                    ? 'bg-emerald-700/70 text-emerald-200'
                    : 'bg-emerald-950/60 text-emerald-400/80'
                }`}
              >
                {item.tag}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Bottom CPU Status Widget */}
      <div className="p-4 bg-emerald-950 border-t border-emerald-800 mt-auto shrink-0">
        <div className="text-[10px] uppercase text-emerald-400 font-bold mb-2 tracking-wider flex items-center justify-between">
          <span>CPU STATUS</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        </div>
        <div className="flex items-center justify-between text-[11px] mb-1 text-emerald-200">
          <span>Clock Frequency</span>
          <span className="text-emerald-400 font-mono font-bold">50 MHz</span>
        </div>
        <div className="flex items-center justify-between text-[11px] mb-2 text-emerald-200">
          <span>Mode</span>
          <span className="text-emerald-300 font-mono text-[10px] bg-emerald-900 px-1.5 py-0.5 rounded">
            FORWARDING ON
          </span>
        </div>
        <div className="w-full bg-emerald-900 h-1.5 rounded-full overflow-hidden">
          <div className="bg-emerald-400 h-full w-[84%] rounded-full"></div>
        </div>
      </div>
    </aside>
  );
};

