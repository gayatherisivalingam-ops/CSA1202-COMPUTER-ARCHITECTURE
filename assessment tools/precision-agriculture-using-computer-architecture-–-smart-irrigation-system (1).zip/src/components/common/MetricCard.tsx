import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  id: string;
  title: string;
  value: string | number;
  subValue?: string;
  badge?: string;
  icon: LucideIcon;
  color?: 'emerald' | 'teal' | 'amber' | 'rose' | 'blue' | 'purple';
  description?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  id,
  title,
  value,
  subValue,
  badge,
  icon: Icon,
  color = 'emerald',
  description,
}) => {
  const colorMap = {
    emerald: {
      bg: 'bg-emerald-50 text-emerald-600',
      badgeBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      valueColor: 'text-emerald-700',
    },
    teal: {
      bg: 'bg-teal-50 text-teal-600',
      badgeBg: 'bg-teal-50 text-teal-700 border-teal-200',
      valueColor: 'text-teal-700',
    },
    amber: {
      bg: 'bg-amber-50 text-amber-600',
      badgeBg: 'bg-amber-50 text-amber-700 border-amber-200',
      valueColor: 'text-amber-700',
    },
    rose: {
      bg: 'bg-rose-50 text-rose-600',
      badgeBg: 'bg-rose-50 text-rose-700 border-rose-200',
      valueColor: 'text-rose-700',
    },
    blue: {
      bg: 'bg-blue-50 text-blue-600',
      badgeBg: 'bg-blue-50 text-blue-700 border-blue-200',
      valueColor: 'text-blue-700',
    },
    purple: {
      bg: 'bg-purple-50 text-purple-600',
      badgeBg: 'bg-purple-50 text-purple-700 border-purple-200',
      valueColor: 'text-purple-700',
    },
  };

  const scheme = colorMap[color];

  return (
    <div
      id={id}
      className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between"
    >
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">{title}</span>
          <div className={`p-1.5 rounded-lg ${scheme.bg}`}>
            <Icon className="w-4 h-4" />
          </div>
        </div>

        <div className="flex items-baseline gap-1.5 mt-0.5">
          <span className={`text-2xl lg:text-3xl font-extrabold font-mono tracking-tight text-slate-800`}>
            {value}
          </span>
          {subValue && (
            <span className="text-xs font-semibold text-slate-500 font-mono">{subValue}</span>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100">
        {description && (
          <span className="text-[10px] text-slate-500 font-medium truncate max-w-[130px]">
            {description}
          </span>
        )}
        {badge && (
          <span
            className={`ml-auto text-[9px] font-bold px-1.5 py-0.5 rounded border ${scheme.badgeBg}`}
          >
            {badge}
          </span>
        )}
      </div>
    </div>
  );
};

