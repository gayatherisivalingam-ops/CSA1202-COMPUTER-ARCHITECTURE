import React from 'react';
import { Droplets, Thermometer, Wind, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { toTwosComplement, toQ8_8 } from '../../utils/arithmeticEngine';

interface SensorCardProps {
  type: 'moisture' | 'temperature' | 'humidity';
  value: number;
  unit: string;
  status: { label: string; color: string; bg: string };
  min: number;
  max: number;
  onChange?: (val: number) => void;
  interactive?: boolean;
}

export const SensorCard: React.FC<SensorCardProps> = ({
  type,
  value,
  unit,
  status,
  min,
  max,
  onChange,
  interactive = false,
}) => {
  const isMoisture = type === 'moisture';
  const isTemp = type === 'temperature';
  const isHumidity = type === 'humidity';

  const Icon = isMoisture ? Droplets : isTemp ? Thermometer : Wind;
  const iconBg = isMoisture ? 'bg-blue-50 text-blue-600' : isTemp ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-600';
  const progressColor = isMoisture
    ? 'bg-blue-500'
    : isTemp
    ? 'bg-red-500'
    : 'bg-emerald-500';

  const title = isMoisture ? 'Soil Moisture' : isTemp ? 'Ambient Temp' : 'Relative Humidity';
  const sensorTag = isMoisture ? 'SENSOR 01' : isTemp ? 'SENSOR 02' : 'SENSOR 03';
  const percentage = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));

  // Binary and Fixed-Point Representation
  const intVal = Math.round(value);
  const binary8Bit = toTwosComplement(intVal, 8);
  const q8_8 = toQ8_8(value);

  return (
    <div
      id={`sensor-card-${type}`}
      className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between"
    >
      <div>
        <div className="flex justify-between items-start mb-2">
          <div className={`p-2 rounded-lg ${iconBg}`}>
            <Icon className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
            {sensorTag}
          </span>
        </div>

        <div className="text-2xl font-bold text-slate-800 font-mono tracking-tight">
          {value}{unit}
        </div>

        <div className="text-xs text-slate-500 font-medium mt-0.5 flex items-center justify-between">
          <span>{title}:</span>
          <span
            className={`font-semibold ${
              status.label.includes('Critical') || status.label.includes('Low')
                ? 'text-orange-600'
                : status.label.includes('High') || status.label.includes('Alert')
                ? 'text-red-600'
                : 'text-emerald-600'
            }`}
          >
            {status.label}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-300 ${progressColor}`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>

      {/* Interactive Slider */}
      {interactive && onChange && (
        <div className="mt-3 pt-2.5 border-t border-slate-100">
          <div className="flex items-center justify-between text-[11px] mb-1">
            <span className="text-slate-500">Fine Tune</span>
            <span className="font-mono font-bold text-slate-700">{value}{unit}</span>
          </div>
          <input
            type="range"
            min={min}
            max={max}
            step={isTemp ? 0.5 : 1}
            value={value}
            onChange={(e) => onChange(Number(e.target.value))}
            className="w-full accent-emerald-600 bg-slate-200 rounded-lg cursor-pointer h-1.5"
          />
        </div>
      )}

      {/* Register readout */}
      <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-mono text-slate-400">
        <span>ADC: <strong className="text-slate-600">{binary8Bit}</strong></span>
        <span>Q8.8: <strong className="text-slate-600">{q8_8.hex}</strong></span>
      </div>
    </div>
  );
};

