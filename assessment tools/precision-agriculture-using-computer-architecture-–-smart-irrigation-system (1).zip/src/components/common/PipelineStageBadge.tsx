import React from 'react';
import { PipelineStageName } from '../../types';

interface PipelineStageBadgeProps {
  stage: PipelineStageName | 'STALL' | 'FLUSH' | null;
  instruction?: string;
  isActive?: boolean;
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
}

export const STAGE_CONFIG: Record<
  PipelineStageName | 'STALL' | 'FLUSH',
  { label: string; name: string; color: string; bg: string; border: string; desc: string }
> = {
  IF: {
    label: 'IF',
    name: 'Instruction Fetch',
    color: 'text-emerald-700',
    bg: 'bg-emerald-50',
    border: 'border-emerald-300',
    desc: 'Fetches 32-bit instruction from memory at PC address into IF/ID register.',
  },
  ID: {
    label: 'ID',
    name: 'Instruction Decode',
    color: 'text-blue-700',
    bg: 'bg-blue-50',
    border: 'border-blue-300',
    desc: 'Decodes opcode, reads source registers (R1..R8), detects data hazards.',
  },
  EX: {
    label: 'EX',
    name: 'Execute / ALU',
    color: 'text-purple-700',
    bg: 'bg-purple-50',
    border: 'border-purple-300',
    desc: 'Executes ALU arithmetic (Booth Mult, Restoring Div, Add/Sub) & branch target calculation.',
  },
  MEM: {
    label: 'MEM',
    name: 'Memory Access',
    color: 'text-amber-700',
    bg: 'bg-amber-50',
    border: 'border-amber-300',
    desc: 'Reads sensor ADC values or writes valve actuation commands to data memory / I/O.',
  },
  WB: {
    label: 'WB',
    name: 'Write Back',
    color: 'text-slate-700',
    bg: 'bg-slate-100',
    border: 'border-slate-300',
    desc: 'Writes ALU result or memory-loaded sensor data back into destination register.',
  },
  STALL: {
    label: 'STALL',
    name: 'Pipeline Stall / Bubble',
    color: 'text-rose-700',
    bg: 'bg-rose-50',
    border: 'border-rose-300',
    desc: 'NOP bubble inserted to resolve hazard without forwarding.',
  },
  FLUSH: {
    label: 'FLUSH',
    name: 'Pipeline Flush',
    color: 'text-orange-700',
    bg: 'bg-orange-50',
    border: 'border-orange-300',
    desc: 'Speculative instruction discarded due to branch misprediction.',
  },
};

export const PipelineStageBadge: React.FC<PipelineStageBadgeProps> = ({
  stage,
  instruction,
  isActive = false,
  onClick,
  size = 'md',
}) => {
  if (!stage) {
    return (
      <div className="px-2 py-1 rounded bg-slate-100 border border-slate-200 text-slate-400 font-mono text-[10px] text-center">
        IDLE
      </div>
    );
  }

  const config = STAGE_CONFIG[stage] || STAGE_CONFIG.IF;

  const sizeClasses = {
    sm: 'px-1.5 py-0.5 text-[10px]',
    md: 'px-2.5 py-1 text-xs',
    lg: 'px-4 py-2 text-sm',
  };

  return (
    <button
      onClick={onClick}
      className={`inline-flex flex-col items-center justify-center font-mono font-bold rounded border transition-all cursor-pointer ${
        config.bg
      } ${config.border} ${config.color} ${sizeClasses[size]} ${
        isActive ? 'ring-2 ring-emerald-500 shadow-xs' : 'hover:opacity-90'
      }`}
      title={`${config.name}: ${config.desc}`}
    >
      <span>{config.label}</span>
      {instruction && (
        <span className="text-[9px] font-normal text-slate-600 truncate max-w-[90px]">
          {instruction}
        </span>
      )}
    </button>
  );
};

