import React, { useState } from 'react';
import {
  Binary,
  Cpu,
  Layers,
  Calculator,
  ArrowRight,
  RotateCcw,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  ListOrdered,
  Sigma,
} from 'lucide-react';
import { SensorData } from '../../types';
import {
  generateBoothMultiplication,
  generateRestoringDivision,
  analyzeIEEE754,
  toTwosComplement,
  toQ8_8,
} from '../../utils/arithmeticEngine';

interface ArithmeticProcessingViewProps {
  sensor: SensorData;
}

export const ArithmeticProcessingView: React.FC<ArithmeticProcessingViewProps> = ({ sensor }) => {
  const [activeTab, setActiveTab] = useState<'booth' | 'division' | 'ieee754' | 'integer'>('booth');

  // Booth Multiplication parameters
  const [boothM, setBoothM] = useState<number>(Math.round(sensor.temperature > 0 ? sensor.temperature % 15 : 6));
  const [boothQ, setBoothQ] = useState<number>(3);
  const [boothBits, setBoothBits] = useState<number>(5);

  // Restoring Division parameters
  const [divDividend, setDivDividend] = useState<number>(Math.round(sensor.soilMoisture % 30 || 22));
  const [divDivisor, setDivDivisor] = useState<number>(4);
  const [divBits, setDivBits] = useState<number>(5);

  // IEEE 754 Interactive Float parameter
  const [customFloat, setCustomFloat] = useState<number>(sensor.temperature);
  const [floatInputStr, setFloatInputStr] = useState<string>(sensor.temperature.toString());

  // Integer ALU calculation parameters
  const [intA, setIntA] = useState<number>(Math.round(sensor.soilMoisture));
  const [intB, setIntB] = useState<number>(Math.round(sensor.temperature));

  const boothResult = generateBoothMultiplication(boothM, boothQ, boothBits);
  const divisionResult = generateRestoringDivision(divDividend, divDivisor, divBits);
  const floatBreakdown = analyzeIEEE754(customFloat);

  const handleFloatChange = (str: string) => {
    setFloatInputStr(str);
    const parsed = parseFloat(str);
    if (!isNaN(parsed)) {
      setCustomFloat(parsed);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
              <Binary className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 tracking-tight">
              Arithmetic Processing & ALU Algorithms
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Explore hardware-level arithmetic: Booth's 2's Complement Multiplier, Restoring Division, and IEEE-754 Single-Precision representation.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-1 p-1 bg-slate-50 rounded-lg border border-slate-200 self-start md:self-auto overflow-x-auto max-w-full">
          <button
            onClick={() => setActiveTab('booth')}
            className={`px-2.5 py-1 rounded text-xs font-bold transition whitespace-nowrap cursor-pointer ${
              activeTab === 'booth'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Booth's Multiplication
          </button>
          <button
            onClick={() => setActiveTab('division')}
            className={`px-2.5 py-1 rounded text-xs font-bold transition whitespace-nowrap cursor-pointer ${
              activeTab === 'division'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Restoring Division
          </button>
          <button
            onClick={() => setActiveTab('ieee754')}
            className={`px-2.5 py-1 rounded text-xs font-bold transition whitespace-nowrap cursor-pointer ${
              activeTab === 'ieee754'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            IEEE 754 Floating-Point
          </button>
          <button
            onClick={() => setActiveTab('integer')}
            className={`px-2.5 py-1 rounded text-xs font-bold transition whitespace-nowrap cursor-pointer ${
              activeTab === 'integer'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Integer Arithmetic
          </button>
        </div>
      </div>

      {/* TAB 1: Booth's Multiplication Algorithm */}
      {activeTab === 'booth' && (
        <div className="space-y-4">
          <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span>Booth's Signed Multiplication Algorithm</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono font-bold">
                    2's Complement Hardware Multiplier
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Used in the Smart Irrigation ALU to scale evaporation coefficients by temperature in hardware without conditional sign branching.
                </p>
              </div>

              {/* Interactive Controls for Multiplicand (M) and Multiplier (Q) */}
              <div className="flex items-center gap-2.5 bg-slate-50 p-2 rounded-lg border border-slate-200">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-600 font-mono">M:</span>
                  <input
                    type="number"
                    min="-15"
                    max="15"
                    value={boothM}
                    onChange={(e) => setBoothM(Number(e.target.value))}
                    className="w-12 px-1 py-0.5 bg-white border border-slate-200 rounded text-center text-xs font-bold font-mono text-emerald-800"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-600 font-mono">Q:</span>
                  <input
                    type="number"
                    min="-15"
                    max="15"
                    value={boothQ}
                    onChange={(e) => setBoothQ(Number(e.target.value))}
                    className="w-12 px-1 py-0.5 bg-white border border-slate-200 rounded text-center text-xs font-bold font-mono text-slate-800"
                  />
                </div>
              </div>
            </div>

            {/* Algorithm Overview Summary Banner */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4 font-mono text-xs">
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="text-[9px] text-slate-400 uppercase font-bold">Multiplicand (M)</div>
                <div className="text-sm font-bold text-slate-800 mt-0.5">
                  {boothResult.multiplicand} <span className="text-[10px] text-slate-400">({boothResult.mBinary}₂)</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="text-[9px] text-slate-400 uppercase font-bold">Multiplier (Q)</div>
                <div className="text-sm font-bold text-slate-800 mt-0.5">
                  {boothResult.multiplier} <span className="text-[10px] text-slate-400">({boothResult.qBinary}₂)</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="text-[9px] text-slate-400 uppercase font-bold">Hardware Bits (n)</div>
                <div className="text-sm font-bold text-amber-700 mt-0.5">
                  {boothBits} Bits <span className="text-[10px] text-slate-400">(Count = {boothBits})</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200">
                <div className="text-[9px] text-emerald-800 uppercase font-bold">Product [A, Q]</div>
                <div className="text-sm font-extrabold text-emerald-800 mt-0.5">
                  {boothResult.result} <span className="text-[10px] text-emerald-600 font-normal">({boothResult.resultBinary}₂)</span>
                </div>
              </div>
            </div>

            {/* Booth's Execution Table */}
            <div className="overflow-x-auto rounded-lg border border-slate-200">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-50 text-slate-500 uppercase text-[9px] border-b border-slate-200">
                  <tr>
                    <th className="p-2.5">Step</th>
                    <th className="p-2.5">Operation</th>
                    <th className="p-2.5 text-center">Accumulator (A)</th>
                    <th className="p-2.5 text-center">Multiplier (Q)</th>
                    <th className="p-2.5 text-center">Q₋₁</th>
                    <th className="p-2.5 text-center">M</th>
                    <th className="p-2.5 text-center">Count</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {boothResult.steps.map((step, idx) => {
                    const isShift = step.action.includes('Arithmetic Right Shift');
                    const isInit = step.step === 0;

                    return (
                      <tr
                        key={idx}
                        className={`hover:bg-slate-50 transition ${
                          isShift ? 'bg-slate-50/50' : ''
                        }`}
                      >
                        <td className="p-2.5 font-bold text-slate-500">{step.step}</td>
                        <td className="p-2.5 font-semibold text-slate-700">
                          <span
                            className={`inline-block px-1.5 py-0.5 rounded text-[10px] ${
                              isInit
                                ? 'bg-slate-100 text-slate-700'
                                : isShift
                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            }`}
                          >
                            {step.action}
                          </span>
                        </td>
                        <td className="p-2.5 text-center font-bold text-emerald-700 tracking-wider">
                          {step.A}
                        </td>
                        <td className="p-2.5 text-center font-bold text-slate-800 tracking-wider">
                          {step.Q}
                        </td>
                        <td className="p-2.5 text-center font-bold text-amber-700">{step.Q_prev}</td>
                        <td className="p-2.5 text-center text-slate-500">{step.M}</td>
                        <td className="p-2.5 text-center font-bold text-purple-700">{step.count}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Restoring Division */}
      {activeTab === 'division' && (
        <div className="space-y-4">
          <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span>Restoring Division Algorithm</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 font-mono font-bold">
                    Hardware Divider
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Computes sensor normalization ratios (e.g. soil deficit fractions and flow-rate divisions per sprinkler emitter).
                </p>
              </div>

              {/* Division Inputs */}
              <div className="flex items-center gap-2.5 bg-slate-50 p-2 rounded-lg border border-slate-200">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-600 font-mono">Q (Dividend):</span>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    value={divDividend}
                    onChange={(e) => setDivDividend(Number(e.target.value))}
                    className="w-12 px-1 py-0.5 bg-white border border-slate-200 rounded text-center text-xs font-bold font-mono text-blue-700"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-600 font-mono">M (Divisor):</span>
                  <input
                    type="number"
                    min="1"
                    max="15"
                    value={divDivisor}
                    onChange={(e) => setDivDivisor(Number(e.target.value))}
                    className="w-12 px-1 py-0.5 bg-white border border-slate-200 rounded text-center text-xs font-bold font-mono text-amber-700"
                  />
                </div>
              </div>
            </div>

            {/* Division Result Summary Banner */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4 font-mono text-xs">
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="text-[9px] text-slate-400 uppercase font-bold">Dividend (Q)</div>
                <div className="text-sm font-bold text-blue-700 mt-0.5">
                  {divisionResult.dividend} <span className="text-[10px] text-slate-400">({divisionResult.qBinary}₂)</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="text-[9px] text-slate-400 uppercase font-bold">Divisor (M)</div>
                <div className="text-sm font-bold text-amber-700 mt-0.5">
                  {divisionResult.divisor} <span className="text-[10px] text-slate-400">({divisionResult.mBinary}₂)</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200">
                <div className="text-[9px] text-emerald-800 uppercase font-bold">Quotient (Q)</div>
                <div className="text-sm font-extrabold text-emerald-800 mt-0.5">
                  {divisionResult.quotient} <span className="text-[10px] text-emerald-600 font-normal">({divisionResult.quotient.toString(2)}₂)</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-purple-50 border border-purple-200">
                <div className="text-[9px] text-purple-800 uppercase font-bold">Remainder (A)</div>
                <div className="text-sm font-extrabold text-purple-800 mt-0.5">
                  {divisionResult.remainder} <span className="text-[10px] text-purple-600 font-normal">({divisionResult.remainder.toString(2)}₂)</span>
                </div>
              </div>
            </div>

            {/* Division Steps Table */}
            <div className="overflow-x-auto rounded-lg border border-slate-200">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-50 text-slate-500 uppercase text-[9px] border-b border-slate-200">
                  <tr>
                    <th className="p-2.5">Step</th>
                    <th className="p-2.5">Action</th>
                    <th className="p-2.5 text-center">Accumulator (A)</th>
                    <th className="p-2.5 text-center">Quotient (Q)</th>
                    <th className="p-2.5 text-center">Divisor (M)</th>
                    <th className="p-2.5 text-center">Count</th>
                    <th className="p-2.5">Hardware Commentary</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {divisionResult.steps.map((step, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition">
                      <td className="p-2.5 font-bold text-slate-500">{step.step}</td>
                      <td className="p-2.5 font-semibold text-slate-700">{step.action}</td>
                      <td className="p-2.5 text-center font-bold text-purple-700 tracking-wider">
                        {step.A}
                      </td>
                      <td className="p-2.5 text-center font-bold text-blue-700 tracking-wider">
                        {step.Q}
                      </td>
                      <td className="p-2.5 text-center text-slate-500">{step.M}</td>
                      <td className="p-2.5 text-center font-bold text-amber-700">{step.count}</td>
                      <td className="p-2.5 text-slate-500 text-[10px]">{step.comment}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: IEEE 754 Single-Precision Floating-Point */}
      {activeTab === 'ieee754' && (
        <div className="space-y-4">
          <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span>IEEE 754 Single-Precision (32-Bit) Floating Point</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono font-bold">
                    FPU Coprocessor Format
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Representation of calibrated analog sensor data: 1 Sign Bit + 8 Biased Exponent Bits (Bias=127) + 23 Mantissa Bits.
                </p>
              </div>

              {/* Interactive Input */}
              <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-200">
                <span className="text-xs text-slate-600 font-mono">Enter Float:</span>
                <input
                  type="text"
                  value={floatInputStr}
                  onChange={(e) => handleFloatChange(e.target.value)}
                  className="w-20 px-1.5 py-0.5 bg-white border border-slate-200 rounded text-center text-xs font-bold font-mono text-emerald-700 focus:outline-none focus:border-emerald-500"
                  placeholder="e.g. 31.5"
                />
                <button
                  onClick={() => handleFloatChange(sensor.temperature.toString())}
                  className="px-2 py-0.5 rounded bg-slate-200 text-[10px] text-slate-700 hover:bg-slate-300 font-bold transition"
                  title="Use current sensor temperature"
                >
                  Use Temp ({sensor.temperature}°C)
                </button>
              </div>
            </div>

            {/* Visual 32-Bit Register Diagram */}
            <div className="space-y-2 mb-4 font-mono">
              <div className="flex items-center justify-between text-[11px] text-slate-500 px-1">
                <span>Bit 31 (Sign)</span>
                <span>Bits 30-23 (Biased Exponent, Bias=127)</span>
                <span>Bits 22-0 (Significand / Mantissa)</span>
              </div>

              <div className="grid grid-cols-32 gap-0.5 p-2 rounded-lg bg-slate-50 border border-slate-200 overflow-x-auto">
                {/* Sign Bit (1 bit) */}
                <div className="p-2 rounded bg-rose-50 border border-rose-200 text-center">
                  <div className="text-[8px] text-rose-700 uppercase font-bold">Sign (S)</div>
                  <div className="text-base font-black text-rose-700 mt-0.5">{floatBreakdown.signBit}</div>
                </div>

                {/* Exponent Bits (8 bits) */}
                <div className="col-span-8 p-2 rounded bg-amber-50 border border-amber-200 text-center">
                  <div className="text-[8px] text-amber-700 uppercase font-bold">Exponent (E) [8 Bits]</div>
                  <div className="text-base font-black text-amber-700 mt-0.5 tracking-widest">
                    {floatBreakdown.exponentBits}
                  </div>
                </div>

                {/* Mantissa Bits (23 bits) */}
                <div className="col-span-23 p-2 rounded bg-emerald-50 border border-emerald-200 text-center">
                  <div className="text-[8px] text-emerald-700 uppercase font-bold">Mantissa / Fraction (M) [23 Bits]</div>
                  <div className="text-xs sm:text-sm font-black text-emerald-700 mt-0.5 tracking-wider break-all">
                    {floatBreakdown.storedMantissaBits}
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Decoding Breakdown */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs">
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                  Mathematical Reconstruction:
                </div>
                <div className="p-2 rounded bg-white text-emerald-800 border border-emerald-200 font-bold text-[11px]">
                  Value = (-1)ˢ × (1 + Mantissa) × 2^(Exponent - 127)
                </div>
                <div className="space-y-1 text-slate-600 text-[10px]">
                  <div className="flex justify-between py-0.5 border-b border-slate-200">
                    <span>Sign:</span>
                    <span className="text-rose-700 font-bold">
                      {floatBreakdown.signBit === '0' ? '+1 (Positive)' : '-1 (Negative)'}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-200">
                    <span>Biased Exponent:</span>
                    <span className="text-amber-700 font-bold">{floatBreakdown.biasedExponent}</span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-200">
                    <span>Unbiased Exponent (E - 127):</span>
                    <span className="text-amber-700 font-bold">{floatBreakdown.unbiasedExponent}</span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-200">
                    <span>Normalized Mantissa:</span>
                    <span className="text-emerald-700 font-bold">{floatBreakdown.mantissaBits.slice(0, 16)}...</span>
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                  Hexadecimal & Memory Footprint:
                </div>
                <div className="space-y-1.5">
                  <div className="p-2.5 rounded bg-white border border-slate-200 flex justify-between items-center">
                    <span className="text-slate-500 text-[11px]">32-Bit Hex:</span>
                    <span className="text-lg font-extrabold text-emerald-800">{floatBreakdown.hex}</span>
                  </div>
                  <div className="p-2.5 rounded bg-white border border-slate-200 flex justify-between items-center">
                    <span className="text-slate-500 text-[11px]">Format Category:</span>
                    <span className="text-xs font-bold text-slate-800 uppercase">{floatBreakdown.type} Float</span>
                  </div>
                  <div className="p-2.5 rounded bg-white border border-slate-200 flex justify-between items-center">
                    <span className="text-slate-500 text-[11px]">Reconstructed:</span>
                    <span className="text-xs font-bold text-slate-800">{floatBreakdown.exactReconstructed}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Standard Integer ALU Operations */}
      {activeTab === 'integer' && (
        <div className="space-y-4">
          <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span>Integer ALU Execution Unit</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono font-bold">
                    32-Bit Integer Adder / Shifter
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Demonstrates fundamental integer operations used in the smart irrigation instruction set.
                </p>
              </div>

              <div className="flex items-center gap-2.5 bg-slate-50 p-2 rounded-lg border border-slate-200">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-600 font-mono">A (Moisture):</span>
                  <input
                    type="number"
                    value={intA}
                    onChange={(e) => setIntA(Number(e.target.value))}
                    className="w-14 px-1 py-0.5 bg-white border border-slate-200 rounded text-center text-xs font-bold font-mono text-emerald-700"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-600 font-mono">B (Temp):</span>
                  <input
                    type="number"
                    value={intB}
                    onChange={(e) => setIntB(Number(e.target.value))}
                    className="w-14 px-1 py-0.5 bg-white border border-slate-200 rounded text-center text-xs font-bold font-mono text-slate-800"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono text-xs">
              {/* Addition */}
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1.5">
                <div className="text-[10px] text-slate-400 font-bold uppercase">1. ADD (A + B)</div>
                <div className="text-lg font-extrabold text-emerald-700">{intA + intB}</div>
                <div className="text-[10px] text-slate-500">Binary: {toTwosComplement(intA + intB, 8)}₂</div>
                <div className="text-[9px] text-slate-400">Used for accumulating deficit + evaporation factors.</div>
              </div>

              {/* Subtraction */}
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1.5">
                <div className="text-[10px] text-slate-400 font-bold uppercase">2. SUB (A - B)</div>
                <div className="text-lg font-extrabold text-blue-700">{intA - intB}</div>
                <div className="text-[10px] text-slate-500">Binary: {toTwosComplement(intA - intB, 8)}₂</div>
                <div className="text-[9px] text-slate-400">Used for target moisture deficit subtraction.</div>
              </div>

              {/* Multiplication */}
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1.5">
                <div className="text-[10px] text-slate-400 font-bold uppercase">3. MUL (A × B)</div>
                <div className="text-lg font-extrabold text-amber-700">{intA * intB}</div>
                <div className="text-[10px] text-slate-500">Binary: {toTwosComplement(intA * intB, 16)}₂</div>
                <div className="text-[9px] text-slate-400">Evaluated via Booth's hardware multiplier.</div>
              </div>

              {/* Division */}
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1.5">
                <div className="text-[10px] text-slate-400 font-bold uppercase">4. DIV (A / B)</div>
                <div className="text-lg font-extrabold text-purple-700">
                  {intB !== 0 ? Math.floor(intA / intB) : 'NaN'}
                </div>
                <div className="text-[10px] text-slate-500">
                  Remainder: {intB !== 0 ? intA % intB : '0'}
                </div>
                <div className="text-[9px] text-slate-400">Evaluated via Restoring Shift-Subtract logic.</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

