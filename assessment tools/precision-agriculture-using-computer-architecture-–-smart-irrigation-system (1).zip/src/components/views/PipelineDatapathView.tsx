import React, { useState, useEffect, useRef } from 'react';
import {
  GitCommit,
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  Cpu,
  Layers,
  Zap,
  ShieldAlert,
  ArrowRight,
  Sparkles,
  Info,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';
import { SensorData, PipelineStageName } from '../../types';
import { STAGE_CONFIG } from '../common/PipelineStageBadge';
import {
  simulateFullPipeline,
  getIrrigationInstructionSet,
} from '../../utils/pipelineSimulator';

interface PipelineDatapathViewProps {
  sensor: SensorData;
}

export const PipelineDatapathView: React.FC<PipelineDatapathViewProps> = ({ sensor }) => {
  const [currentCycle, setCurrentCycle] = useState<number>(1);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeedMs, setPlaybackSpeedMs] = useState<number>(1000);
  const [forwardingEnabled, setForwardingEnabled] = useState<boolean>(true);
  const [selectedStageDetail, setSelectedStageDetail] = useState<PipelineStageName>('EX');

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Compute full simulation records
  const simulation = simulateFullPipeline(sensor, forwardingEnabled, 'dynamic-2bit', false);
  const instructions = getIrrigationInstructionSet(sensor);
  const maxCycles = simulation.totalCycles;

  // Auto-play timer
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setCurrentCycle((prev) => {
          if (prev >= maxCycles) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, playbackSpeedMs);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, maxCycles, playbackSpeedMs]);

  const handleNext = () => {
    if (currentCycle < maxCycles) setCurrentCycle((c) => c + 1);
  };

  const handlePrev = () => {
    if (currentCycle > 1) setCurrentCycle((c) => c - 1);
  };

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentCycle(1);
  };

  // Find which instruction is currently in each stage at `currentCycle`
  const activeStageMap: Record<PipelineStageName, string | null> = {
    IF: null,
    ID: null,
    EX: null,
    MEM: null,
    WB: null,
  };

  simulation.records.forEach((rec) => {
    const stageAtCycle = rec.stageHistory[currentCycle];
    if (stageAtCycle && stageAtCycle !== 'STALL' && stageAtCycle !== 'FLUSH') {
      activeStageMap[stageAtCycle] = `${rec.instructionId}: ${rec.mnemonic} ${rec.operands}`;
    }
  });

  // Active hazards and forwarding at current cycle
  const currentHazards = simulation.hazards.filter((h) => h.cycle === currentCycle);
  const currentForwarding = simulation.forwardingEvents.filter((f) => f.cycle === currentCycle);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header & Simulator Control Bar */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
              <GitCommit className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 tracking-tight">
              5-Stage Pipelined Processor Datapath
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time instruction flow: Instruction Fetch ➔ Decode ➔ Execute ➔ Memory ➔ Write Back with Forwarding & Hazard Interlocks.
          </p>
        </div>

        {/* Playback Controls & Toggles */}
        <div className="flex flex-wrap items-center gap-2 bg-slate-50 p-1.5 rounded-lg border border-slate-200">
          <button
            onClick={handlePrev}
            disabled={currentCycle <= 1}
            className="p-1.5 rounded bg-white hover:bg-slate-100 disabled:opacity-40 text-slate-700 border border-slate-200 transition cursor-pointer"
            title="Previous Cycle"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            id="pipeline-play-pause-btn"
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition cursor-pointer"
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-current" /> Pause
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" /> {currentCycle >= maxCycles ? 'Replay' : 'Run Pipeline'}
              </>
            )}
          </button>

          <button
            onClick={handleNext}
            disabled={currentCycle >= maxCycles}
            className="p-1.5 rounded bg-white hover:bg-slate-100 disabled:opacity-40 text-slate-700 border border-slate-200 transition cursor-pointer"
            title="Next Cycle"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleReset}
            className="p-1.5 rounded bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition cursor-pointer"
            title="Reset Simulation"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          {/* Current Cycle Display */}
          <div className="px-2.5 py-1 rounded bg-white border border-slate-200 font-mono text-xs text-center min-w-[90px]">
            <span className="text-slate-400 text-[9px] block uppercase font-bold">Cycle</span>
            <span className="font-extrabold text-emerald-700 text-xs">
              {currentCycle} / {maxCycles}
            </span>
          </div>

          {/* Forwarding Toggle Switch */}
          <button
            onClick={() => setForwardingEnabled(!forwardingEnabled)}
            className={`px-2.5 py-1 rounded text-xs font-mono font-bold border transition cursor-pointer ${
              forwardingEnabled
                ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                : 'bg-rose-100 text-rose-800 border-rose-300'
            }`}
            title="Toggle EX/MEM and MEM/WB bypass forwarding paths"
          >
            Forwarding: {forwardingEnabled ? 'ON' : 'OFF'}
          </button>
        </div>
      </div>

      {/* Interactive 5-Stage Datapath Visual Block Diagram */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <span>Microarchitectural Datapath Schematic</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-mono font-bold">
              Cycle {currentCycle}
            </span>
          </h3>
          <span className="text-xs text-slate-400 font-mono hidden sm:inline">
            Click any stage block to inspect hardware internals
          </span>
        </div>

        {/* Datapath Diagram Flow */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
          {(['IF', 'ID', 'EX', 'MEM', 'WB'] as const).map((stageKey, idx) => {
            const config = STAGE_CONFIG[stageKey];
            const activeInst = activeStageMap[stageKey];
            const isSelected = selectedStageDetail === stageKey;

            return (
              <div
                key={stageKey}
                onClick={() => setSelectedStageDetail(stageKey)}
                className={`relative p-3.5 rounded-lg border transition-all cursor-pointer flex flex-col justify-between min-h-[140px] ${
                  config.bg
                } ${config.border} ${
                  isSelected
                    ? 'ring-2 ring-emerald-500 shadow-xs bg-slate-50'
                    : 'hover:bg-slate-50'
                }`}
              >
                {/* Stage Header */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-xs font-black font-mono tracking-wider ${config.color}`}>
                      Stage {idx + 1}: {config.label}
                    </span>
                    {activeInst && (
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                    )}
                  </div>
                  <div className="text-xs font-bold text-slate-800">{config.name}</div>
                </div>

                {/* Currently Occupying Instruction */}
                <div className="my-2 p-1.5 rounded bg-white border border-slate-200">
                  <div className="text-[8px] uppercase font-bold text-slate-400">Active Instruction:</div>
                  <div
                    className={`text-xs font-mono font-bold truncate mt-0.5 ${
                      activeInst ? config.color : 'text-slate-400'
                    }`}
                  >
                    {activeInst || 'IDLE (Bubble)'}
                  </div>
                </div>

                {/* Pipeline Register Name */}
                <div className="text-[9px] font-mono text-slate-500 flex items-center justify-between border-t border-slate-200 pt-1">
                  <span>Reg: {idx < 4 ? `${stageKey}/${(['IF', 'ID', 'EX', 'MEM', 'WB'] as const)[idx + 1]}` : 'Commit'}</span>
                  <span className="text-[9px] text-emerald-600 font-bold">Inspect ➔</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Forwarding Bus Indicator */}
        {currentForwarding.length > 0 && (
          <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center gap-2.5 text-xs font-mono text-emerald-900">
            <Zap className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <strong className="font-bold">Active EX Bypass Forwarding: </strong>
              {currentForwarding.map((f, i) => (
                <span key={i}>
                  [{f.fromStage} ➔ {f.toStage} for register {f.register} from {f.fromInst} to {f.toInst}]
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Hazard Alarm Box if present at current cycle */}
        {currentHazards.length > 0 && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 flex items-center gap-2.5 text-xs font-mono text-rose-900">
            <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
            <div>
              <strong className="font-bold">Hazard Detected in Cycle {currentCycle}: </strong>
              {currentHazards[0].description} ({currentHazards[0].action})
            </div>
          </div>
        )}

        {/* Selected Stage Detail Drawer */}
        <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-2.5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-800 font-mono flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              Stage Inspection: {STAGE_CONFIG[selectedStageDetail].name} ({selectedStageDetail})
            </h4>
            <span className="text-[10px] text-slate-400 font-mono">RISC Pipelined Datapath Component</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-2.5 rounded bg-white border border-slate-200">
              <span className="text-slate-400 text-[9px] uppercase font-bold block mb-0.5">Hardware Units:</span>
              <p className="text-slate-700 leading-relaxed font-mono text-[11px]">
                {selectedStageDetail === 'IF' && 'Program Counter (PC), Instruction Memory, PC+4 Adder.'}
                {selectedStageDetail === 'ID' && 'Dual-Port Register File (Read R1..R8), Immediate Sign-Extender, Hazard Unit.'}
                {selectedStageDetail === 'EX' && '32-Bit ALU, Booth Multiplier, Branch Target Adder, Forwarding Muxes.'}
                {selectedStageDetail === 'MEM' && 'Data Memory / Sensor ADC Memory-Mapped IO Buffer, Solenoid Valve IO Port.'}
                {selectedStageDetail === 'WB' && 'Write-Back Mux, Register File Write Port, Destination Reg (Rd).'}
              </p>
            </div>

            <div className="p-2.5 rounded bg-white border border-slate-200">
              <span className="text-slate-400 text-[9px] uppercase font-bold block mb-0.5">Current Function:</span>
              <p className="text-slate-700 leading-relaxed text-[11px]">
                {STAGE_CONFIG[selectedStageDetail].desc}
              </p>
            </div>

            <div className="p-2.5 rounded bg-white border border-slate-200">
              <span className="text-slate-400 text-[9px] uppercase font-bold block mb-0.5">Active Pipeline Reg:</span>
              <p className="text-slate-700 leading-relaxed font-mono text-[10px]">
                {selectedStageDetail === 'IF' && 'IF/ID: Holds Fetched 32-bit Opcode & Next PC Address.'}
                {selectedStageDetail === 'ID' && 'ID/EX: Holds Decoded Operands (RegA, RegB), Control Signals, DestReg.'}
                {selectedStageDetail === 'EX' && 'EX/MEM: Holds ALU Computed Water Demand & Zero/Branch Flag.'}
                {selectedStageDetail === 'MEM' && 'MEM/WB: Holds Loaded Sensor ADC Values or ALU Output.'}
                {selectedStageDetail === 'WB' && 'Register File updated on falling edge of clock.'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Cycle-by-Cycle Pipeline Timing Chart (Grid) */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <span>Pipeline Timing Diagram (Space-Time Matrix)</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Cycle-by-cycle execution of all 11 smart irrigation instructions across clock cycles.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold text-[10px]">
              Forwarding {forwardingEnabled ? 'Enabled' : 'Disabled'}
            </span>
          </div>
        </div>

        {/* Scrollable Timing Matrix Table */}
        <div className="overflow-x-auto rounded-lg border border-slate-200">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[9px] border-b border-slate-200 sticky top-0">
              <tr>
                <th className="p-2 bg-slate-50 sticky left-0 z-10 min-w-[150px]">Instruction</th>
                {Array.from({ length: Math.min(24, maxCycles) }).map((_, i) => {
                  const cyc = i + 1;
                  const isCurrent = cyc === currentCycle;
                  return (
                    <th
                      key={cyc}
                      className={`p-2 text-center min-w-[42px] ${
                        isCurrent
                          ? 'bg-emerald-100 text-emerald-900 font-extrabold border-b-2 border-emerald-600'
                          : ''
                      }`}
                    >
                      C{cyc}
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {simulation.records.map((rec) => {
                return (
                  <tr key={rec.instructionId} className="hover:bg-slate-50 transition">
                    {/* Instruction Name */}
                    <td className="p-2 bg-white sticky left-0 z-10 font-bold text-slate-800 border-r border-slate-200">
                      <div className="text-xs text-emerald-800">{rec.instructionId}: {rec.mnemonic}</div>
                      <div className="text-[10px] text-slate-500 font-normal truncate max-w-[140px]">
                        {rec.operands}
                      </div>
                    </td>

                    {/* Cycle Badges */}
                    {Array.from({ length: Math.min(24, maxCycles) }).map((_, i) => {
                      const cyc = i + 1;
                      const stage = rec.stageHistory[cyc];
                      const isCurrent = cyc === currentCycle;

                      if (!stage) {
                        return <td key={cyc} className={`p-1 text-center ${isCurrent ? 'bg-emerald-50' : ''}`} />;
                      }

                      const isStall = stage === 'STALL';
                      const isFlush = stage === 'FLUSH';
                      const config = STAGE_CONFIG[stage] || STAGE_CONFIG.IF;

                      return (
                        <td
                          key={cyc}
                          className={`p-1 text-center ${isCurrent ? 'bg-emerald-50' : ''}`}
                        >
                          <span
                            className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-bold border transition ${
                              isStall
                                ? 'bg-rose-50 text-rose-700 border-rose-200'
                                : isFlush
                                ? 'bg-orange-50 text-orange-700 border-orange-200'
                                : `${config.bg} ${config.color} ${config.border}`
                            }`}
                          >
                            {stage}
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

