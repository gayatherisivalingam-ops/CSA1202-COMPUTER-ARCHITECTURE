import React, { useState } from 'react';
import {
  ShieldAlert,
  Zap,
  Layers,
  GitFork,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Info,
  Layers2,
  TrendingDown,
} from 'lucide-react';
import { SensorData } from '../../types';
import { calculateIrrigationDemand } from '../../utils/irrigationModel';

interface HazardAnalysisViewProps {
  sensor: SensorData;
}

export const HazardAnalysisView: React.FC<HazardAnalysisViewProps> = ({ sensor }) => {
  const [activeTab, setActiveTab] = useState<'data' | 'structural' | 'control'>('data');
  const [dataForwardingOn, setDataForwardingOn] = useState<boolean>(true);
  const [structuralFixOn, setStructuralFixOn] = useState<boolean>(false);
  const [predictedTaken, setPredictedTaken] = useState<boolean>(true);

  const decision = calculateIrrigationDemand(sensor);
  const actualBranchOutcome = decision.required;
  const isBranchMispredicted = predictedTaken !== actualBranchOutcome;

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-rose-50 text-rose-600 border border-rose-200">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 tracking-tight">
              Pipeline Hazard Analysis & Resolution
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Analyze Data Hazards (RAW, Load-Use), Structural Hazards (Memory Bus Contention), and Control Hazards (Branch Penalty & Flush).
          </p>
        </div>

        {/* Hazard Category Selector */}
        <div className="flex items-center gap-1 p-1 bg-slate-50 rounded-lg border border-slate-200 self-start md:self-auto overflow-x-auto max-w-full">
          <button
            onClick={() => setActiveTab('data')}
            className={`px-3 py-1 rounded text-xs font-bold transition cursor-pointer whitespace-nowrap ${
              activeTab === 'data'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            1. Data Hazards
          </button>
          <button
            onClick={() => setActiveTab('structural')}
            className={`px-3 py-1 rounded text-xs font-bold transition cursor-pointer whitespace-nowrap ${
              activeTab === 'structural'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            2. Structural Hazards
          </button>
          <button
            onClick={() => setActiveTab('control')}
            className={`px-3 py-1 rounded text-xs font-bold transition cursor-pointer whitespace-nowrap ${
              activeTab === 'control'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            3. Control Hazards
          </button>
        </div>
      </div>

      {/* SECTION 1: DATA HAZARDS */}
      {activeTab === 'data' && (
        <div className="space-y-4">
          <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span>Read-After-Write (RAW) Data Hazards & Bypassing</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 font-mono font-bold">
                    Dependency Interlocks
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Occurs when an instruction requires sensor register data before the preceding instruction has written it back into the register file.
                </p>
              </div>

              <button
                onClick={() => setDataForwardingOn(!dataForwardingOn)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold border transition cursor-pointer ${
                  dataForwardingOn
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border-rose-200'
                }`}
              >
                Forwarding: {dataForwardingOn ? 'ENABLED (Bypass Active)' : 'DISABLED (Hardware Stalls)'}
              </button>
            </div>

            {/* Case A: ALU-ALU RAW Hazard */}
            <div className="p-3.5 sm:p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-emerald-600" />
                  Case A: ALU ➔ ALU Data Hazard (EX/MEM ➔ EX Bypass with 0 Stalls)
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-700 font-bold">
                  {dataForwardingOn ? '0 Stall Cycles' : '2 Stall Cycles'}
                </span>
              </div>

              {/* Code Snippet with highlighted dependency */}
              <div className="p-3 rounded-lg bg-white border border-slate-200 font-mono text-xs space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-emerald-700 font-bold">I4: SUB</span>
                  <span className="text-emerald-800 font-bold bg-emerald-50 px-1 rounded border border-emerald-200">
                    R4 (Deficit)
                  </span>
                  <span className="text-slate-500">, R_TARGET, R1</span>
                  <span className="text-slate-400 text-[10px] ml-auto">// Writes to R4 at Cycle 5</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-blue-700 font-bold">I6: ADD</span>
                  <span className="text-slate-700">R6,</span>
                  <span className="text-rose-800 font-bold bg-rose-50 px-1 rounded border border-rose-200">
                    R4 (Deficit)
                  </span>
                  <span className="text-slate-500">, R5</span>
                  <span className="text-slate-400 text-[10px] ml-auto">// Needs R4 at Cycle 4 (EX stage)</span>
                </div>
              </div>

              {/* Status Box */}
              <div className={`p-3 rounded-lg border text-xs font-mono flex items-center justify-between ${
                dataForwardingOn
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-rose-50 border-rose-200 text-rose-800'
              }`}>
                <div>
                  <strong>Hardware Status: </strong>
                  {dataForwardingOn
                    ? 'Hazard Detected ➔ Forwarded from EX/MEM stage to ALU input mux. Stall Required: NO (0 Cycles).'
                    : 'Hazard Detected ➔ No Forwarding unit. Pipeline stalled for 2 cycles until I4 completes WB stage.'}
                </div>
              </div>
            </div>

            {/* Case B: Load-Use Data Hazard */}
            <div className="p-3.5 sm:p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  Case B: Load-Use Hazard (Requires 1-Cycle Stall Even with Forwarding)
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white border border-slate-200 text-amber-800 font-bold">
                  {dataForwardingOn ? '1 Stall Cycle' : '3 Stall Cycles'}
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white border border-slate-200 font-mono text-xs space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-amber-700 font-bold">I1: LOAD</span>
                  <span className="text-amber-800 font-bold bg-amber-50 px-1 rounded border border-amber-200">
                    R1 (SoilMoisture)
                  </span>
                  <span className="text-slate-500">, [0x2000]</span>
                  <span className="text-slate-400 text-[10px] ml-auto">// Loaded from sensor memory at MEM stage (C4)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-700 font-bold">I4: SUB</span>
                  <span className="text-slate-700">R4, R_TGT,</span>
                  <span className="text-rose-800 font-bold bg-rose-50 px-1 rounded border border-rose-200">
                    R1
                  </span>
                  <span className="text-slate-400 text-[10px] ml-auto">// Needs R1 at Cycle 3 (EX stage)</span>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs font-mono text-amber-800">
                <strong>Load-Use Resolution: </strong>
                Data is not ready until MEM stage finishes. The Hazard Detection Unit inserts 1 NOP bubble into ID/EX, holding PC & IF/ID, then forwards from MEM/WB ➔ EX.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: STRUCTURAL HAZARDS */}
      {activeTab === 'structural' && (
        <div className="space-y-4">
          <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span>Structural Hazards (Hardware Resource Contention)</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 font-mono font-bold">
                    Single Port Memory Bus
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Occurs when two pipeline stages attempt to access the same physical hardware resource simultaneously.
                </p>
              </div>

              <button
                onClick={() => setStructuralFixOn(!structuralFixOn)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold border transition cursor-pointer ${
                  structuralFixOn
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-amber-50 text-amber-800 border-amber-200'
                }`}
              >
                Architecture: {structuralFixOn ? 'Harvard (Split I/D Cache)' : 'Von Neumann (Unified Memory)'}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs">
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-amber-800 font-bold uppercase text-[10px] flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  Resource Conflict Manifestation:
                </div>
                <div className="p-2.5 rounded bg-white border border-slate-200 space-y-1.5 text-slate-700 text-[11px]">
                  <div>
                    <strong className="text-slate-900">Conflict Cycle: </strong>Cycle 4
                  </div>
                  <div>
                    <strong className="text-slate-900">Conflicting Stages: </strong>
                    <span className="text-blue-700 font-bold">IF Stage</span> (Fetching I4) vs{' '}
                    <span className="text-amber-700 font-bold">MEM Stage</span> (Loading sensor data from I1)
                  </div>
                  <div>
                    <strong className="text-slate-900">Contended Hardware: </strong>Single Shared Memory Address/Data Bus
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-emerald-800 font-bold uppercase text-[10px] flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Architectural Fix:
                </div>
                <div className="p-2.5 rounded bg-white border border-slate-200 space-y-1.5 text-slate-700 text-[11px]">
                  <div>
                    <strong className="text-slate-900">Without Fix: </strong>IF stage is stalled for 1 cycle (inserted bubble).
                  </div>
                  <div>
                    <strong className="text-slate-900">With Split Cache (Harvard): </strong>Separate Instruction Cache (I-Cache) and Data Cache (D-Cache) allow concurrent simultaneous access with 0 stalls.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: CONTROL HAZARDS */}
      {activeTab === 'control' && (
        <div className="space-y-4">
          <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span>Control Hazards & Branch Misprediction Flushes</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-bold">
                    Branch Penalty
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Arises when a conditional irrigation branch decision is being evaluated in the EX stage, while new instructions were speculatively fetched.
                </p>
              </div>

              <div className="flex items-center gap-1.5 bg-slate-50 p-1 rounded-lg border border-slate-200">
                <span className="text-xs text-slate-600 font-mono px-1.5">Prediction:</span>
                <button
                  onClick={() => setPredictedTaken(true)}
                  className={`px-2.5 py-1 rounded text-xs font-bold font-mono transition cursor-pointer ${
                    predictedTaken
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  PREDICT TAKEN
                </button>
                <button
                  onClick={() => setPredictedTaken(false)}
                  className={`px-2.5 py-1 rounded text-xs font-bold font-mono transition cursor-pointer ${
                    !predictedTaken
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  PREDICT NOT TAKEN
                </button>
              </div>
            </div>

            {/* Branch Decision Evaluation Box */}
            <div className="p-3.5 sm:p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-3 font-mono text-xs">
              <div className="p-3 rounded-lg bg-white border border-slate-200 space-y-1">
                <div className="text-slate-400 font-bold uppercase text-[9px]">Smart Irrigation Branch Logic:</div>
                <div className="text-emerald-800 font-bold">
                  IF (Calculated Demand &gt; 0) ➔ BRANCH IRRIGATION_ON (TAKEN) ELSE (STANDBY)
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                  <div className="text-[9px] text-slate-400 uppercase font-bold">Actual Outcome</div>
                  <div className="text-sm font-extrabold text-emerald-800 mt-0.5">
                    {actualBranchOutcome ? 'BRANCH TAKEN (Irrigate)' : 'NOT TAKEN (Standby)'}
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                  <div className="text-[9px] text-slate-400 uppercase font-bold">Predicted Outcome</div>
                  <div className="text-sm font-extrabold text-indigo-800 mt-0.5">
                    {predictedTaken ? 'PREDICTED TAKEN' : 'PREDICTED NOT TAKEN'}
                  </div>
                </div>

                <div className={`p-2.5 rounded-lg border ${
                  isBranchMispredicted
                    ? 'bg-rose-50 border-rose-200 text-rose-800'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                }`}>
                  <div className="text-[9px] uppercase font-bold">Prediction Result</div>
                  <div className="text-sm font-black mt-0.5">
                    {isBranchMispredicted ? 'MISPREDICTION (Flush 2 Cycles)' : 'CORRECT (0 Penalty)'}
                  </div>
                </div>
              </div>

              {/* Flush Animation Visualizer */}
              {isBranchMispredicted && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 space-y-1">
                  <div className="text-rose-800 font-bold flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                    Pipeline Flush Triggered in EX Stage:
                  </div>
                  <p className="text-slate-600 text-[10px]">
                    2 incorrectly fetched instructions in IF and ID stages are wiped with NOP bubbles (Control signal multiplexers set to zero). PC redirected to correct branch target address.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

