export interface SensorData {
  soilMoisture: number; // percentage 0 - 100%
  temperature: number;  // Celsius 0 - 50°C
  humidity: number;     // percentage 0 - 100%
  targetMoisture: number; // optimal target e.g. 60%
  baseWaterRequirement: number; // L/min e.g. 10
}

export interface IrrigationDecision {
  required: boolean;
  waterFlowRate: number; // L/min
  soilMoistureDeficit: number;
  tempFactor: number;
  humidityFactor: number;
  rawScore: number;
  status: 'Critical - Immediate Irrigation' | 'Moderate Irrigation Required' | 'Optimal - No Irrigation' | 'Over-saturated - Drainage Alert';
  formulaBreakdown: {
    base: number;
    deficitComponent: number;
    tempComponent: number;
    humidityComponent: number;
    total: number;
  };
}

export type PipelineStageName = 'IF' | 'ID' | 'EX' | 'MEM' | 'WB';

export interface InstructionDef {
  id: string;
  pc: number;
  mnemonic: string;
  operands: string;
  type: 'ALU' | 'LOAD' | 'STORE' | 'BRANCH' | 'NOP';
  destReg?: string;
  srcRegs?: string[];
  description: string;
  targetAddress?: number;
  branchCondition?: (regs: Record<string, number>) => boolean;
}

export interface InstructionExecutionRecord {
  instructionId: string;
  mnemonic: string;
  operands: string;
  stageHistory: Record<number, PipelineStageName | 'STALL' | 'FLUSH'>;
  startCycle: number;
  endCycle?: number;
  hazardDetected?: {
    type: 'RAW_DATA' | 'LOAD_USE' | 'STRUCTURAL' | 'CONTROL';
    resolvedBy: 'FORWARD_EX_EX' | 'FORWARD_MEM_EX' | 'STALL_INSERTED' | 'FLUSH_PIPELINE' | 'PREDICTION_HIT';
    description: string;
    sourceInstructionId?: string;
  };
}

export interface PipelineSimulationState {
  currentCycle: number;
  maxCycles: number;
  isRunning: boolean;
  speedMs: number;
  registers: Record<string, number>;
  dataMemory: Record<number, number>;
  pc: number;
  instructions: InstructionDef[];
  activePipeline: {
    IF: string | null;
    ID: string | null;
    EX: string | null;
    MEM: string | null;
    WB: string | null;
  };
  pipelineRegisters: {
    IF_ID: { pc: number; instruction: InstructionDef | null } | null;
    ID_EX: { instruction: InstructionDef | null; readData1: number; readData2: number; destReg?: string } | null;
    EX_MEM: { instruction: InstructionDef | null; aluResult: number; writeData: number; destReg?: string } | null;
    MEM_WB: { instruction: InstructionDef | null; memData: number; aluResult: number; destReg?: string } | null;
  };
  executionHistory: InstructionExecutionRecord[];
  hazards: Array<{
    cycle: number;
    type: 'Data (RAW)' | 'Load-Use Data' | 'Structural (Memory Bus)' | 'Control (Branch)';
    instructionId: string;
    description: string;
    action: string;
    stalls: number;
  }>;
  totalStalls: number;
  totalFlushes: number;
  forwardingCount: number;
  branchPredictions: {
    total: number;
    correct: number;
    incorrect: number;
    strategy: BranchStrategy;
  };
  settings: {
    forwardingEnabled: boolean;
    branchStrategy: BranchStrategy;
    structuralHazardSim: boolean;
  };
}

export type BranchStrategy = 'always-taken' | 'always-not-taken' | 'dynamic-1bit' | 'dynamic-2bit';

export interface BoothStep {
  step: number;
  action: string;
  A: string;
  Q: string;
  Q_prev: string;
  M: string;
  count: number;
  decimalAccumulator: number;
}

export interface DivisionStep {
  step: number;
  action: string;
  A: string;
  Q: string;
  M: string;
  count: number;
  restored: boolean;
  comment: string;
}

export interface IEEE754Breakdown {
  value: number;
  signBit: string;
  exponentBits: string;
  biasedExponent: number;
  unbiasedExponent: number;
  mantissaBits: string;
  storedMantissaBits: string;
  hex: string;
  binary32: string;
  exactReconstructed: number;
  type: 'normalized' | 'denormalized' | 'zero' | 'infinity' | 'nan';
}

export interface PerformanceMetrics {
  instructionCount: number;
  unoptimizedCycles: number;
  optimizedCycles: number;
  unoptimizedStalls: number;
  optimizedStalls: number;
  unoptimizedCPI: number;
  optimizedCPI: number;
  unoptimizedThroughput: number; // instructions / cycle
  optimizedThroughput: number;
  unoptimizedLatency: number; // ns or cycles
  optimizedLatency: number;
  speedup: number;
  stallReductionPercent: number;
  estimatedCpuEnergySavedPct: number;
}
