import React, { useState } from 'react';
import {
  Menu,
  X,
  Play,
  RotateCcw,
  Sparkles,
  GitCommit,
  Layers,
  Zap,
  Activity,
  CheckCircle2,
} from 'lucide-react';
import { SensorData, IrrigationDecision, PerformanceMetrics } from './types';
import { calculateIrrigationDemand } from './utils/irrigationModel';
import { calculatePerformanceMetrics } from './utils/pipelineSimulator';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/views/DashboardView';
import { SensorInputView } from './components/views/SensorInputView';
import { ArithmeticProcessingView } from './components/views/ArithmeticProcessingView';
import { PipelineDatapathView } from './components/views/PipelineDatapathView';
import { HazardAnalysisView } from './components/views/HazardAnalysisView';
import { BranchPredictionView } from './components/views/BranchPredictionView';
import { PerformanceEvaluationView } from './components/views/PerformanceEvaluationView';
import { PseudocodeView } from './components/views/PseudocodeView';
import { ResultsView } from './components/views/ResultsView';
import { AboutProjectView } from './components/views/AboutProjectView';

export default function App() {
  // Global Shared Sensor State
  const [sensor, setSensor] = useState<SensorData>({
    soilMoisture: 32.5,
    temperature: 28.4,
    humidity: 45.0,
    targetMoisture: 60.0,
    baseWaterRequirement: 8.0,
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simNotification, setSimNotification] = useState<string | null>(null);

  // Dynamically compute irrigation decision and performance metrics from current sensor data
  const decision: IrrigationDecision = calculateIrrigationDemand(sensor);
  const metrics: PerformanceMetrics = calculatePerformanceMetrics(sensor);

  // Trigger full pipeline simulation run
  const handleRunSimulation = () => {
    setIsSimulating(true);
    setSimNotification('Processor pipeline executed all 11 ISA instructions in hardware!');
    setTimeout(() => {
      setIsSimulating(false);
      setTimeout(() => setSimNotification(null), 3500);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#F0F4F2] text-slate-900 flex flex-col selection:bg-emerald-500 selection:text-white antialiased">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        sensor={sensor}
        setSensor={setSensor}
        decision={decision}
        metrics={metrics}
        onRunSimulation={handleRunSimulation}
      />

      {/* Mobile Top Bar with Navigation Toggle */}
      <div className="lg:hidden flex items-center justify-between px-4 py-2 bg-white border-b border-slate-200 text-xs">
        <button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200"
        >
          {isSidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>Menu & Modules</span>
        </button>

        <span className="font-mono text-emerald-700 font-bold uppercase text-[11px]">
          {activeTab}
        </span>
      </div>

      {/* Main Layout Body */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isOpen={isSidebarOpen}
          setIsOpen={setIsSidebarOpen}
        />

        {/* Content View Outlet */}
        <main className="flex-1 p-4 sm:p-5 lg:p-6 overflow-y-auto max-w-full">
          {/* Notification Banner on Run */}
          {simNotification && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-100/90 border border-emerald-300 text-emerald-900 text-xs sm:text-sm font-mono flex items-center gap-2.5 shadow-xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              <span className="font-semibold">{simNotification}</span>
            </div>
          )}

          {/* View Routing Switch */}
          {activeTab === 'dashboard' && (
            <DashboardView
              sensor={sensor}
              setSensor={setSensor}
              decision={decision}
              metrics={metrics}
              setActiveTab={(tab) => setActiveTab(tab)}
              onRunSimulation={handleRunSimulation}
            />
          )}

          {activeTab === 'sensors' && (
            <SensorInputView
              sensor={sensor}
              setSensor={setSensor}
              decision={decision}
              metrics={metrics}
              onRunSimulation={handleRunSimulation}
              setActiveTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'arithmetic' && <ArithmeticProcessingView sensor={sensor} />}

          {activeTab === 'pipeline' && <PipelineDatapathView sensor={sensor} />}

          {activeTab === 'hazards' && <HazardAnalysisView sensor={sensor} />}

          {activeTab === 'branch' && <BranchPredictionView sensor={sensor} />}

          {activeTab === 'performance' && (
            <PerformanceEvaluationView metrics={metrics} sensor={sensor} />
          )}

          {activeTab === 'pseudocode' && <PseudocodeView />}

          {activeTab === 'results' && (
            <ResultsView sensor={sensor} decision={decision} metrics={metrics} />
          )}

          {activeTab === 'about' && <AboutProjectView />}
        </main>
      </div>

      {/* Global Application Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-3 px-4 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            CSA1202 Computer Architecture – Precision Agriculture Smart Irrigation System
          </span>
          <span className="text-emerald-700 font-bold">5-Stage RISC Pipelined Datapath</span>
        </div>
      </footer>
    </div>
  );
}

