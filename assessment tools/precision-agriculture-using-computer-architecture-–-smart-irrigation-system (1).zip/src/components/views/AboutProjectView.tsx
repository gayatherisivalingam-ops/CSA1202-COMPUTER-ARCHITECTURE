import React from 'react';
import {
  GraduationCap,
  BookOpen,
  Cpu,
  Droplet,
  Users,
  Lightbulb,
  Award,
  ArrowRight,
  Sparkles,
  ExternalLink,
  Layers,
} from 'lucide-react';

export const AboutProjectView: React.FC = () => {
  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header */}
      <div className="p-4 sm:p-6 rounded-xl bg-white border border-slate-200 shadow-xs space-y-2">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-800 text-xs font-mono font-bold border border-emerald-200">
          <GraduationCap className="w-3.5 h-3.5 text-emerald-600" /> Academic Project Documentation
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-800 tracking-tight">
          Precision Agriculture using Computer Architecture
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-3xl leading-relaxed">
          Smart Irrigation System implemented as an educational simulator demonstrating RISC pipelined processor design, hardware arithmetic units (Booth Multiplier, Restoring Divider, IEEE-754 Single Precision), hazard mitigation, and dynamic branch prediction.
        </p>
      </div>

      {/* Course & Metadata Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4 font-mono text-xs">
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-1.5">
          <div className="text-emerald-800 font-bold uppercase text-[11px] flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5" /> Course Details
          </div>
          <div className="text-base font-bold text-slate-800">CSA1202</div>
          <p className="text-slate-500">Computer Architecture & Microprocessor Design</p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-1.5">
          <div className="text-teal-800 font-bold uppercase text-[11px] flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5" /> Processor Target
          </div>
          <div className="text-base font-bold text-slate-800">5-Stage RISC Datapath</div>
          <p className="text-slate-500">50 MHz Embedded Edge Core with Forwarding Unit</p>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-1.5">
          <div className="text-amber-800 font-bold uppercase text-[11px] flex items-center gap-1.5">
            <Droplet className="w-3.5 h-3.5" /> Domain Application
          </div>
          <div className="text-base font-bold text-slate-800">Precision Smart Irrigation</div>
          <p className="text-slate-500">Low-latency closed-loop soil moisture optimization</p>
        </div>
      </div>

      {/* Core Architectural Concepts Covered */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-600" />
          <span>Core Computer Architecture Learning Objectives</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs font-mono">
          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="text-emerald-800 font-bold">1. Hardware Arithmetic</div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              Booth's 2's complement multiplication algorithm, shift-subtract restoring division, and IEEE-754 32-bit floating point parsing.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="text-teal-800 font-bold">2. 5-Stage Pipelining</div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              Instruction Fetch (IF), Instruction Decode (ID), Execution (EX), Memory Access (MEM), and Write-Back (WB) registers.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="text-rose-800 font-bold">3. Data Hazard Resolution</div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              RAW dependency identification, EX/MEM and MEM/WB bypass forwarding multiplexers, and 1-cycle Load-Use interlock stalls.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="text-amber-800 font-bold">4. Structural Hazard Mitigation</div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              Unified memory bus contention analysis vs Harvard split I-Cache/D-Cache architecture.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="text-indigo-800 font-bold">5. Dynamic Branch Prediction</div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              2-Bit saturating counter finite state machine (11, 10, 01, 00) and 2-cycle pipeline flush mitigation.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="text-purple-800 font-bold">6. Quantitative Benchmarking</div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              Cycles Per Instruction (CPI), instruction throughput (IPC), Amdahl's speedup ratio, and embedded processor energy reduction.
            </p>
          </div>
        </div>
      </div>

      {/* Real-World Agronomic Edge Relevance */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-2">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-amber-500" />
          <span>Real-World Agricultural Impact & IoT Edge Computing</span>
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed">
          Modern solar-powered precision farming nodes operate under stringent thermal and battery energy constraints in remote agricultural fields. By designing an optimized pipelined RISC core with hardware bypassing and branch prediction, the processor completes environmental calculations in fewer clock cycles, spending over 95% of its duty cycle in microampere deep-sleep mode while ensuring millisecond response to dry soil conditions.
        </p>
      </div>
    </div>
  );
};

