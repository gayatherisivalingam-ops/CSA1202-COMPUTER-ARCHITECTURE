import { SensorData, IrrigationDecision, PerformanceMetrics } from '../types';
import { simulateFullPipeline } from './pipelineSimulator';
import { simulateBranchPredictionSequence } from './branchPredictor';

export function exportSimulationToJSON(
  sensor: SensorData,
  decision: IrrigationDecision,
  metrics: PerformanceMetrics
) {
  const pipelineTrace = simulateFullPipeline(sensor, true, 'dynamic-2bit', false);
  const branchData = simulateBranchPredictionSequence(sensor.soilMoisture);

  const payload = {
    metadata: {
      application: 'Precision Agriculture using Computer Architecture – Smart Irrigation System',
      course: 'CSA1202 – Computer Architecture',
      timestamp: new Date().toISOString(),
      version: '1.0.0',
    },
    sensorInputs: {
      soilMoisturePct: sensor.soilMoisture,
      temperatureC: sensor.temperature,
      humidityPct: sensor.humidity,
      targetMoisturePct: sensor.targetMoisture,
    },
    irrigationDecision: {
      required: decision.required,
      valveStatus: decision.status,
      waterFlowRateLitersPerMin: decision.waterFlowRate,
      soilMoistureDeficit: decision.soilMoistureDeficit,
      formulaBreakdown: decision.formulaBreakdown,
    },
    pipelinePerformance: {
      instructionCount: metrics.instructionCount,
      unoptimized: {
        totalExecutionCycles: metrics.unoptimizedCycles,
        CPI: metrics.unoptimizedCPI,
        throughputInstPerCycle: metrics.unoptimizedThroughput,
        latencyNs: metrics.unoptimizedLatency,
        stallCycles: metrics.unoptimizedStalls,
      },
      optimized: {
        totalExecutionCycles: metrics.optimizedCycles,
        CPI: metrics.optimizedCPI,
        throughputInstPerCycle: metrics.optimizedThroughput,
        latencyNs: metrics.optimizedLatency,
        stallCycles: metrics.optimizedStalls,
        forwardingEventsCount: pipelineTrace.forwardingEvents.length,
      },
      comparativeGains: {
        speedup: `${metrics.speedup}x`,
        stallReduction: `${metrics.stallReductionPercent}%`,
        cpuEnergyEfficiencyGain: `${metrics.estimatedCpuEnergySavedPct}%`,
      },
    },
    hazardAnalysis: pipelineTrace.hazards,
    branchPrediction: {
      alwaysTakenAccuracyPct: branchData.alwaysTakenAccuracy,
      alwaysNotTakenAccuracyPct: branchData.alwaysNotTakenAccuracy,
      twoBitSaturatingAccuracyPct: branchData.twoBitAccuracy,
      totalTestBranches: branchData.totalBranches,
    },
  };

  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(payload, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `Smart_Irrigation_CA_Simulation_${Date.now()}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export function exportSimulationToCSV(
  sensor: SensorData,
  decision: IrrigationDecision,
  metrics: PerformanceMetrics
) {
  const rows = [
    ['Precision Agriculture using Computer Architecture - Simulation Export'],
    ['Course', 'CSA1202 - Computer Architecture'],
    ['Timestamp', new Date().toISOString()],
    [],
    ['--- SENSOR INPUTS ---'],
    ['Parameter', 'Value', 'Unit'],
    ['Soil Moisture', sensor.soilMoisture, '%'],
    ['Temperature', sensor.temperature, '°C'],
    ['Relative Humidity', sensor.humidity, '%'],
    ['Target Moisture', sensor.targetMoisture, '%'],
    [],
    ['--- IRRIGATION ACTUATION OUTPUT ---'],
    ['Decision', decision.required ? 'IRRIGATION ACTIVE' : 'IRRIGATION IDLE'],
    ['Valve Flow Rate', decision.waterFlowRate, 'L/min'],
    ['Moisture Deficit', decision.soilMoistureDeficit, '%'],
    ['Status Alert', decision.status],
    [],
    ['--- PIPELINE PERFORMANCE EVALUATION ---'],
    ['Metric', 'Unoptimized (No Forwarding)', 'Optimized (Forwarding + Branch Pred)', 'Gain / Improvement'],
    ['Total Execution Cycles', metrics.unoptimizedCycles, metrics.optimizedCycles, `${metrics.speedup}x Speedup`],
    ['Cycles Per Instruction (CPI)', metrics.unoptimizedCPI, metrics.optimizedCPI, `${((metrics.unoptimizedCPI - metrics.optimizedCPI) / metrics.unoptimizedCPI * 100).toFixed(1)}% Lower CPI`],
    ['Throughput (Inst/Cycle)', metrics.unoptimizedThroughput, metrics.optimizedThroughput, 'Increased Throughput'],
    ['Latency (ns @ 50MHz)', metrics.unoptimizedLatency, metrics.optimizedLatency, `${metrics.unoptimizedLatency - metrics.optimizedLatency} ns faster`],
    ['Total Stall & Flush Cycles', metrics.unoptimizedStalls, metrics.optimizedStalls, `${metrics.stallReductionPercent}% Stall Reduction`],
    ['Estimated Processor Energy Saved', '-', `${metrics.estimatedCpuEnergySavedPct}%`, 'Efficiency Improvement'],
  ];

  const csvContent = 'data:text/csv;charset=utf-8,' + rows.map(e => e.map(cell => `"${cell !== undefined ? cell : ''}"`).join(',')).join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `Smart_Irrigation_CA_Report_${Date.now()}.csv`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}
