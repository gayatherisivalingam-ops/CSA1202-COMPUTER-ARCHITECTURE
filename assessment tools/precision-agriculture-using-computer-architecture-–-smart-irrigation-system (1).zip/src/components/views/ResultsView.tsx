import React, { useState } from 'react';
import {
  FileCheck2,
  Download,
  FileSpreadsheet,
  FileCode,
  CheckCircle2,
  Droplet,
  Zap,
  Activity,
  Cpu,
  Clock,
  Layers,
  Sparkles,
} from 'lucide-react';
import { SensorData, IrrigationDecision, PerformanceMetrics } from '../../types';
import { exportSimulationToJSON, exportSimulationToCSV } from '../../utils/exportUtils';
import { simulateFullPipeline } from '../../utils/pipelineSimulator';

interface ResultsViewProps {
  sensor: SensorData;
  decision: IrrigationDecision;
  metrics: PerformanceMetrics;
}

export const ResultsView: React.FC<ResultsViewProps> = ({
  sensor,
  decision,
  metrics,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const pipelineTrace = simulateFullPipeline(sensor, true, 'dynamic-2bit', false);

  const handleDownloadJSON = () => {
    exportSimulationToJSON(sensor, decision, metrics);
    setDownloadSuccess('JSON report exported successfully!');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handleDownloadCSV = () => {
    exportSimulationToCSV(sensor, decision, metrics);
    setDownloadSuccess('CSV spreadsheet exported successfully!');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header with Export Action Buttons */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
              <FileCheck2 className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 tracking-tight">
              Simulation Results & Hardware Report
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Consolidated verification report of sensor inputs, arithmetic executions, pipeline hazard mitigation, and actuation decision.
          </p>
        </div>

        {/* Download Buttons */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            id="export-csv-btn"
            onClick={handleDownloadCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 transition cursor-pointer shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            Download CSV
          </button>
          <button
            id="export-json-btn"
            onClick={handleDownloadJSON}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition cursor-pointer"
          >
            <FileCode className="w-3.5 h-3.5" />
            Download JSON
          </button>
        </div>
      </div>

      {downloadSuccess && (
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-mono flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          {downloadSuccess}
        </div>
      )}

      {/* 3-Section Results Grid (Input ➔ Processing ➔ Output) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 font-mono text-xs">
        {/* Section 1: Inputs */}
        <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-500" />
              1. Analog Sensor Inputs
            </span>
            <span className="text-[10px] text-slate-400 font-bold">ADC 8-Bit</span>
          </div>

          <div className="space-y-2 text-slate-600 text-xs">
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Soil Moisture:</span>
              <span className="font-bold text-blue-700">{sensor.soilMoisture}%</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Temperature:</span>
              <span className="font-bold text-amber-700">{sensor.temperature}°C</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Relative Humidity:</span>
              <span className="font-bold text-teal-700">{sensor.humidity}%</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Target Optimal:</span>
              <span className="font-bold text-slate-800">{sensor.targetMoisture}%</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Calculated Deficit:</span>
              <span className="font-bold text-rose-700">
                {Math.max(0, sensor.targetMoisture - sensor.soilMoisture)}%
              </span>
            </div>
          </div>
        </div>

        {/* Section 2: Pipeline Processing Trace */}
        <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-purple-500" />
              2. Processor Execution
            </span>
            <span className="text-[10px] text-slate-400 font-bold">5-Stage RISC</span>
          </div>

          <div className="space-y-2 text-slate-600 text-xs">
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Instructions Retired:</span>
              <span className="font-bold text-slate-800">{metrics.instructionCount}</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Forwarding Bypasses:</span>
              <span className="font-bold text-emerald-800">
                {pipelineTrace.forwardingEvents.length} Events
              </span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Total Hazard Interlocks:</span>
              <span className="font-bold text-amber-800">{pipelineTrace.hazards.length}</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Load-Use Stalls:</span>
              <span className="font-bold text-rose-700">{pipelineTrace.totalStalls} Cycle</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex justify-between">
              <span>Branch FSM Outcome:</span>
              <span className="font-bold text-slate-800">
                {decision.required ? 'TAKEN' : 'NOT TAKEN'} (Hit)
              </span>
            </div>
          </div>
        </div>

        {/* Section 3: Final Output & Architectural Speedup */}
        <div className="p-4 sm:p-5 rounded-xl bg-emerald-50/50 border border-emerald-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-emerald-200/60">
            <span className="font-bold text-xs text-emerald-800 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600" />
              3. Final Actuation & Speedup
            </span>
            <span className="text-[10px] text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded font-bold">OPTIMIZED</span>
          </div>

          <div className="space-y-2 text-slate-700 text-xs">
            <div className="p-2.5 rounded-lg bg-white border border-emerald-200 flex justify-between items-center">
              <span>Irrigation Solenoid Valve:</span>
              <span
                className={`font-extrabold px-1.5 py-0.5 rounded text-[10px] ${
                  decision.required ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                }`}
              >
                {decision.required ? 'ACTIVE (OPEN)' : 'STANDBY (CLOSED)'}
              </span>
            </div>
            <div className="p-2.5 rounded-lg bg-white border border-emerald-200 flex justify-between">
              <span>Flow Rate Command:</span>
              <span className="font-bold text-emerald-800">{decision.waterFlowRate} L/min</span>
            </div>
            <div className="p-2.5 rounded-lg bg-white border border-emerald-200 flex justify-between">
              <span>Execution Cycles:</span>
              <span className="font-bold text-slate-800">{metrics.optimizedCycles} Cycles</span>
            </div>
            <div className="p-2.5 rounded-lg bg-white border border-emerald-200 flex justify-between">
              <span>Cycles Per Instruction:</span>
              <span className="font-bold text-slate-800">{metrics.optimizedCPI}</span>
            </div>
            <div className="p-2.5 rounded-lg bg-white border border-emerald-200 flex justify-between">
              <span>Speedup Factor:</span>
              <span className="font-extrabold text-emerald-800">{metrics.speedup}x Faster</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

