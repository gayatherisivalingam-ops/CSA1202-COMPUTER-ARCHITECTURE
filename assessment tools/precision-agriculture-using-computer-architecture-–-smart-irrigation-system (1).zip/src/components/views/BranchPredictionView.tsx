import React, { useState } from 'react';
import {
  GitFork,
  CheckCircle2,
  XCircle,
  TrendingUp,
  RotateCcw,
  Sparkles,
  Zap,
  Activity,
  Layers,
  ArrowRight,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { SensorData, BranchStrategy } from '../../types';
import {
  simulateBranchPredictionSequence,
  BranchEvaluationResult,
  STATE_LABELS,
  BranchState,
} from '../../utils/branchPredictor';

interface BranchPredictionViewProps {
  sensor: SensorData;
}

export const BranchPredictionView: React.FC<BranchPredictionViewProps> = ({ sensor }) => {
  const [selectedStrategy, setSelectedStrategy] = useState<BranchStrategy>('dynamic-2bit');
  const [currentFsmState, setCurrentFsmState] = useState<BranchState>('10');

  const branchData: BranchEvaluationResult = simulateBranchPredictionSequence(sensor.soilMoisture);

  const chartData = [
    { name: 'Always Not Taken', accuracy: branchData.alwaysNotTakenAccuracy, color: '#94a3b8' },
    { name: 'Always Taken', accuracy: branchData.alwaysTakenAccuracy, color: '#38bdf8' },
    { name: 'Dynamic 1-Bit', accuracy: branchData.oneBitAccuracy, color: '#f59e0b' },
    { name: 'Dynamic 2-Bit FSM', accuracy: branchData.twoBitAccuracy, color: '#059669' },
  ];

  const getStrategyAccuracy = () => {
    switch (selectedStrategy) {
      case 'always-taken': return branchData.alwaysTakenAccuracy;
      case 'always-not-taken': return branchData.alwaysNotTakenAccuracy;
      case 'dynamic-1bit': return branchData.oneBitAccuracy;
      case 'dynamic-2bit': return branchData.twoBitAccuracy;
    }
  };

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
              <GitFork className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 tracking-tight">
              Branch Prediction Unit & 2-Bit Saturating Counter
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Simulate dynamic branch history tables across 15 diurnal irrigation cycles to mitigate pipeline flush penalties.
          </p>
        </div>

        {/* Strategy Selector */}
        <div className="flex items-center gap-1 p-1 bg-slate-50 rounded-lg border border-slate-200 self-start md:self-auto overflow-x-auto max-w-full">
          {(['always-not-taken', 'always-taken', 'dynamic-1bit', 'dynamic-2bit'] as const).map((strat) => (
            <button
              key={strat}
              onClick={() => setSelectedStrategy(strat)}
              className={`px-2.5 py-1 rounded text-xs font-bold font-mono transition cursor-pointer whitespace-nowrap ${
                selectedStrategy === strat
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {strat === 'always-not-taken' && 'Always Not Taken'}
              {strat === 'always-taken' && 'Always Taken'}
              {strat === 'dynamic-1bit' && '1-Bit Dynamic'}
              {strat === 'dynamic-2bit' && '2-Bit Saturating FSM'}
            </button>
          ))}
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
          <div className="text-[10px] text-slate-400 uppercase font-bold">Total Branches Tested</div>
          <div className="text-xl font-extrabold text-slate-800 font-mono mt-0.5">{branchData.totalBranches} Cycles</div>
          <div className="text-[10px] text-slate-400 mt-0.5">Diurnal farm sensor sequence</div>
        </div>

        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 shadow-xs">
          <div className="text-[10px] text-emerald-800 uppercase font-bold">Strategy Accuracy</div>
          <div className="text-xl font-extrabold text-emerald-800 font-mono mt-0.5">
            {getStrategyAccuracy()}%
          </div>
          <div className="text-[10px] text-emerald-600 mt-0.5">Hit rate over decision stream</div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
          <div className="text-[10px] text-slate-400 uppercase font-bold">Misprediction Penalty</div>
          <div className="text-xl font-extrabold text-rose-700 font-mono mt-0.5">2 Cycles</div>
          <div className="text-[10px] text-slate-400 mt-0.5">Flush IF & ID pipeline stages</div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
          <div className="text-[10px] text-slate-400 uppercase font-bold">2-Bit Saturating State</div>
          <div className="text-base font-extrabold text-slate-800 font-mono mt-0.5">
            {STATE_LABELS[currentFsmState]}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">MSB dictates branch prediction</div>
        </div>
      </div>

      {/* Strategy Comparison Chart & 2-Bit FSM State Diagram */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recharts Bar Chart */}
        <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              <span>Branch Prediction Accuracy Comparison</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-400">Higher is Better</span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 15, right: 15, left: -15, bottom: 15 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} interval={0} />
                <YAxis stroke="#64748b" fontSize={10} domain={[0, 100]} unit="%" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#cbd5e1',
                    borderRadius: '0.5rem',
                    color: '#0f172a',
                    fontFamily: 'monospace',
                    fontSize: '11px',
                    boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
                  }}
                  formatter={(val: number) => [`${val}%`, 'Accuracy']}
                />
                <Bar dataKey="accuracy" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 2-Bit Saturating Counter FSM Diagram */}
        <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-emerald-600" />
              <span>2-Bit Saturating Counter FSM</span>
            </h3>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-50 border border-slate-200 text-slate-600 font-bold">
              Hysteresis Loop
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2.5 font-mono text-xs">
            {/* 11: Strongly Taken */}
            <div
              onClick={() => setCurrentFsmState('11')}
              className={`p-3 rounded-lg border transition cursor-pointer ${
                currentFsmState === '11'
                  ? 'bg-emerald-50 border-emerald-300 ring-1 ring-emerald-500 text-emerald-900'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
              }`}
            >
              <div className="flex justify-between items-center mb-0.5">
                <span className="font-bold text-xs text-emerald-800">11: Strongly Taken</span>
                <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1 rounded font-bold">TAKEN</span>
              </div>
              <p className="text-[9px] text-slate-500">Not Taken ➔ 10 (Weakly Taken).</p>
            </div>

            {/* 10: Weakly Taken */}
            <div
              onClick={() => setCurrentFsmState('10')}
              className={`p-3 rounded-lg border transition cursor-pointer ${
                currentFsmState === '10'
                  ? 'bg-emerald-50 border-emerald-300 ring-1 ring-emerald-500 text-emerald-900'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
              }`}
            >
              <div className="flex justify-between items-center mb-0.5">
                <span className="font-bold text-xs text-slate-800">10: Weakly Taken</span>
                <span className="text-[9px] bg-slate-200 text-slate-800 px-1 rounded font-bold">TAKEN</span>
              </div>
              <p className="text-[9px] text-slate-500">Taken ➔ 11. Not Taken ➔ 01.</p>
            </div>

            {/* 01: Weakly Not Taken */}
            <div
              onClick={() => setCurrentFsmState('01')}
              className={`p-3 rounded-lg border transition cursor-pointer ${
                currentFsmState === '01'
                  ? 'bg-amber-50 border-amber-300 ring-1 ring-amber-500 text-amber-900'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
              }`}
            >
              <div className="flex justify-between items-center mb-0.5">
                <span className="font-bold text-xs text-amber-800">01: Weakly Not Taken</span>
                <span className="text-[9px] bg-amber-100 text-amber-800 px-1 rounded font-bold">NOT TAKEN</span>
              </div>
              <p className="text-[9px] text-slate-500">Taken ➔ 10. Not Taken ➔ 00.</p>
            </div>

            {/* 00: Strongly Not Taken */}
            <div
              onClick={() => setCurrentFsmState('00')}
              className={`p-3 rounded-lg border transition cursor-pointer ${
                currentFsmState === '00'
                  ? 'bg-rose-50 border-rose-300 ring-1 ring-rose-500 text-rose-900'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
              }`}
            >
              <div className="flex justify-between items-center mb-0.5">
                <span className="font-bold text-xs text-rose-800">00: Strongly Not Taken</span>
                <span className="text-[9px] bg-rose-100 text-rose-800 px-1 rounded font-bold">NOT TAKEN</span>
              </div>
              <p className="text-[9px] text-slate-500">Taken ➔ 01 (Weakly Not Taken).</p>
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed font-mono">
            <strong className="text-slate-800">Why 2-bit dynamic prediction excels in agriculture: </strong>
            Diurnal weather conditions have temporal locality (soil remains dry for long stretches during noon and damp after watering). A 2-bit counter avoids mispredicting twice on transient weather blips.
          </div>
        </div>
      </div>

      {/* Simulated 15-Cycle Irrigation History Table */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
          <span>Cycle-by-Cycle Branch Evaluation Trace (15 Diurnal Samples)</span>
        </h3>

        <div className="overflow-x-auto rounded-lg border border-slate-200">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[9px] border-b border-slate-200">
              <tr>
                <th className="p-2.5">Sample</th>
                <th className="p-2.5">Soil Moisture</th>
                <th className="p-2.5">Temp</th>
                <th className="p-2.5">Actual Irrigation</th>
                <th className="p-2.5 text-center">2-Bit State Before</th>
                <th className="p-2.5 text-center">2-Bit Prediction</th>
                <th className="p-2.5 text-center">2-Bit State After</th>
                <th className="p-2.5 text-center">Prediction Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {branchData.history.map((row) => (
                <tr key={row.cycleIndex} className="hover:bg-slate-50 transition">
                  <td className="p-2.5 font-bold text-slate-700">Cycle #{row.cycleIndex}</td>
                  <td className="p-2.5 text-blue-700 font-bold">{row.sensorSoilMoisture}%</td>
                  <td className="p-2.5 text-amber-700 font-bold">{row.temperature}°C</td>
                  <td className="p-2.5">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        row.actualOutcome === 'TAKEN'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {row.actualOutcome}
                    </span>
                  </td>
                  <td className="p-2.5 text-center text-slate-500">{row.twoBitStateBefore}</td>
                  <td className="p-2.5 text-center font-bold text-slate-800">{row.twoBitPrediction}</td>
                  <td className="p-2.5 text-center text-slate-600">{row.twoBitStateAfter}</td>
                  <td className="p-2.5 text-center">
                    {row.isTwoBitCorrect ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-bold text-[10px]">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Hit (0 Penalty)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-rose-700 font-bold text-[10px]">
                        <XCircle className="w-3 h-3 text-rose-600" /> Miss (Flush 2 Cyc)
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

