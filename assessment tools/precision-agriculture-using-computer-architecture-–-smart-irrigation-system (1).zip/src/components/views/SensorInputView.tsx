import React, { useState } from 'react';
import {
  Sliders,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Droplet,
  Thermometer,
  Wind,
  Binary,
  Cpu,
  ArrowRight,
  Sparkles,
  Info,
} from 'lucide-react';
import { SensorData, IrrigationDecision, PerformanceMetrics } from '../../types';
import { toTwosComplement, toQ8_8, analyzeIEEE754 } from '../../utils/arithmeticEngine';
import { getMoistureStatus, getTemperatureStatus, getHumidityStatus } from '../../utils/irrigationModel';

interface SensorInputViewProps {
  sensor: SensorData;
  setSensor: React.Dispatch<React.SetStateAction<SensorData>>;
  decision: IrrigationDecision;
  metrics: PerformanceMetrics;
  onRunSimulation: () => void;
  setActiveTab: (tab: string) => void;
}

export const SensorInputView: React.FC<SensorInputViewProps> = ({
  sensor,
  setSensor,
  decision,
  metrics,
  onRunSimulation,
  setActiveTab,
}) => {
  const [targetMoist, setTargetMoist] = useState(sensor.targetMoisture || 60);
  const [baseWater, setBaseWater] = useState(sensor.baseWaterRequirement || 8.0);
  const [isProcessing, setIsProcessing] = useState(false);

  const moistureStatus = getMoistureStatus(sensor.soilMoisture);
  const tempStatus = getTemperatureStatus(sensor.temperature);
  const humidityStatus = getHumidityStatus(sensor.humidity);

  // Binary/IEEE 754 representations
  const moistureBin = toTwosComplement(Math.round(sensor.soilMoisture), 8);
  const tempBin = toTwosComplement(Math.round(sensor.temperature), 8);
  const humidityBin = toTwosComplement(Math.round(sensor.humidity), 8);

  const moistureFloat = analyzeIEEE754(sensor.soilMoisture);
  const tempFloat = analyzeIEEE754(sensor.temperature);
  const humidityFloat = analyzeIEEE754(sensor.humidity);

  const handleRun = () => {
    setIsProcessing(true);
    onRunSimulation();
    setTimeout(() => {
      setIsProcessing(false);
    }, 400);
  };

  const handleReset = () => {
    setSensor({
      soilMoisture: 35,
      temperature: 31,
      humidity: 58,
      targetMoisture: 60,
      baseWaterRequirement: 8.0,
    });
    setTargetMoist(60);
    setBaseWater(8.0);
  };

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
              <Sliders className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 tracking-tight">
              Interactive Sensor Input & Conversion Unit
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Simulate real-time analog probe signals, ADC quantization, and floating-point conversion for the CPU datapath.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Defaults
          </button>
          <button
            id="sensor-page-run-processor-btn"
            onClick={handleRun}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
          >
            <Play className={`w-3.5 h-3.5 fill-current ${isProcessing ? 'animate-spin' : ''}`} />
            Run Processor
          </button>
        </div>
      </div>

      {/* 3 Main Sensor Sliders with Binary Representation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Sensor 1: Soil Moisture */}
        <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                  <Droplet className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-800">Soil Moisture Sensor</h3>
                  <span className="text-[9px] text-slate-400 font-mono">ADC Channel 0 (ADDR: 0x2000)</span>
                </div>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${moistureStatus.bg} ${moistureStatus.color}`}>
                {moistureStatus.label}
              </span>
            </div>

            {/* Slider & Numeric Input */}
            <div className="space-y-2.5 my-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-600 font-medium">Moisture Level:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={sensor.soilMoisture}
                    onChange={(e) => setSensor((prev) => ({ ...prev, soilMoisture: Number(e.target.value) }))}
                    className="w-14 px-1.5 py-0.5 rounded bg-slate-50 border border-slate-200 text-right text-xs font-bold font-mono text-blue-700 focus:border-blue-500 focus:outline-none"
                  />
                  <span className="text-xs font-bold text-slate-500">%</span>
                </div>
              </div>

              <input
                type="range"
                min="0"
                max="100"
                value={sensor.soilMoisture}
                onChange={(e) => setSensor((prev) => ({ ...prev, soilMoisture: Number(e.target.value) }))}
                className="w-full accent-blue-600 bg-slate-200 rounded-lg cursor-pointer h-1.5"
              />

              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>0% (Bone Dry)</span>
                <span>50%</span>
                <span>100% (Flooded)</span>
              </div>
            </div>
          </div>

          {/* Computer Architecture Data Encoding */}
          <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5 text-xs font-mono">
            <div className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-100">
              <span className="text-slate-500 text-[10px]">8-Bit Binary:</span>
              <span className="text-blue-700 font-bold tracking-wider">{moistureBin}₂</span>
            </div>
            <div className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-100">
              <span className="text-slate-500 text-[10px]">IEEE-754 Hex:</span>
              <span className="text-slate-800 font-bold">{moistureFloat.hex}</span>
            </div>
          </div>
        </div>

        {/* Sensor 2: Temperature */}
        <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-red-50 text-red-600">
                  <Thermometer className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-800">Ambient Temperature</h3>
                  <span className="text-[9px] text-slate-400 font-mono">ADC Channel 1 (ADDR: 0x2004)</span>
                </div>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${tempStatus.bg} ${tempStatus.color}`}>
                {tempStatus.label}
              </span>
            </div>

            {/* Slider & Numeric Input */}
            <div className="space-y-2.5 my-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-600 font-medium">Temperature:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    max="50"
                    step="0.5"
                    value={sensor.temperature}
                    onChange={(e) => setSensor((prev) => ({ ...prev, temperature: Number(e.target.value) }))}
                    className="w-14 px-1.5 py-0.5 rounded bg-slate-50 border border-slate-200 text-right text-xs font-bold font-mono text-red-700 focus:border-red-500 focus:outline-none"
                  />
                  <span className="text-xs font-bold text-slate-500">°C</span>
                </div>
              </div>

              <input
                type="range"
                min="0"
                max="50"
                step="0.5"
                value={sensor.temperature}
                onChange={(e) => setSensor((prev) => ({ ...prev, temperature: Number(e.target.value) }))}
                className="w-full accent-red-600 bg-slate-200 rounded-lg cursor-pointer h-1.5"
              />

              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>0°C (Freezing)</span>
                <span>25°C (Mild)</span>
                <span>50°C (Hot)</span>
              </div>
            </div>
          </div>

          {/* Computer Architecture Data Encoding */}
          <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5 text-xs font-mono">
            <div className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-100">
              <span className="text-slate-500 text-[10px]">8-Bit Binary:</span>
              <span className="text-red-700 font-bold tracking-wider">{tempBin}₂</span>
            </div>
            <div className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-100">
              <span className="text-slate-500 text-[10px]">IEEE-754 Hex:</span>
              <span className="text-slate-800 font-bold">{tempFloat.hex}</span>
            </div>
          </div>
        </div>

        {/* Sensor 3: Humidity */}
        <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
                  <Wind className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-800">Relative Humidity</h3>
                  <span className="text-[9px] text-slate-400 font-mono">ADC Channel 2 (ADDR: 0x2008)</span>
                </div>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${humidityStatus.bg} ${humidityStatus.color}`}>
                {humidityStatus.label}
              </span>
            </div>

            {/* Slider & Numeric Input */}
            <div className="space-y-2.5 my-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-600 font-medium">Humidity Level:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={sensor.humidity}
                    onChange={(e) => setSensor((prev) => ({ ...prev, humidity: Number(e.target.value) }))}
                    className="w-14 px-1.5 py-0.5 rounded bg-slate-50 border border-slate-200 text-right text-xs font-bold font-mono text-emerald-700 focus:border-emerald-500 focus:outline-none"
                  />
                  <span className="text-xs font-bold text-slate-500">%</span>
                </div>
              </div>

              <input
                type="range"
                min="0"
                max="100"
                value={sensor.humidity}
                onChange={(e) => setSensor((prev) => ({ ...prev, humidity: Number(e.target.value) }))}
                className="w-full accent-emerald-600 bg-slate-200 rounded-lg cursor-pointer h-1.5"
              />

              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>0% (Arid)</span>
                <span>50%</span>
                <span>100% (Dew Point)</span>
              </div>
            </div>
          </div>

          {/* Computer Architecture Data Encoding */}
          <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5 text-xs font-mono">
            <div className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-100">
              <span className="text-slate-500 text-[10px]">8-Bit Binary:</span>
              <span className="text-emerald-700 font-bold tracking-wider">{humidityBin}₂</span>
            </div>
            <div className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-100">
              <span className="text-slate-500 text-[10px]">IEEE-754 Hex:</span>
              <span className="text-slate-800 font-bold">{humidityFloat.hex}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Target Parameters & Calculation Breakdown */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2 mb-3">
          <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
            <Cpu className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-bold text-slate-800">
            Irrigation Mathematical Model & ALU Formula Breakdown
          </h3>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
          {/* Formula Display Box */}
          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2.5 font-mono text-xs">
            <div className="text-slate-500 font-bold text-[10px] uppercase tracking-wider">
              Agronomic Evapo-Transpiration Equation:
            </div>
            <div className="p-2.5 rounded bg-white text-emerald-800 border border-emerald-200 leading-relaxed font-bold text-[11px]">
              Water Demand (L/min) = BaseReq + (SoilDeficit × 0.75) + (TempExcess × 0.60) - (HumidityFactor × 0.15)
            </div>

            <div className="space-y-1 text-slate-600 text-[10px]">
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span>Base Water Baseline:</span>
                <span className="text-slate-800 font-bold">{decision.formulaBreakdown.base.toFixed(2)} L/min</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span>Soil Moisture Deficit ({decision.soilMoistureDeficit}% × 0.75):</span>
                <span className="text-blue-700 font-bold">+{decision.formulaBreakdown.deficitComponent.toFixed(2)} L/min</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span>Temperature Evaporation (max(0, {sensor.temperature} - 20) × 0.60):</span>
                <span className="text-red-700 font-bold">+{decision.formulaBreakdown.tempComponent.toFixed(2)} L/min</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span>Humidity Transpiration Offset ({sensor.humidity}% × 0.15):</span>
                <span className="text-emerald-700 font-bold">-{decision.formulaBreakdown.humidityComponent.toFixed(2)} L/min</span>
              </div>
              <div className="flex justify-between py-1.5 text-xs font-extrabold text-emerald-800 pt-2">
                <span>Total Computed Demand:</span>
                <span>{decision.formulaBreakdown.total.toFixed(2)} L/min</span>
              </div>
            </div>
          </div>

          {/* Actuation Output Decision Card */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-slate-500">Processor Actuation State</span>
              <span
                className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                  decision.required
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {decision.required ? 'VALVE ACTIVE' : 'VALVE CLOSED'}
              </span>
            </div>

            <div className="p-3 rounded-lg bg-white border border-slate-200">
              <div className="text-[10px] uppercase font-bold text-slate-400">Recommended Flow Rate</div>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span className="text-2xl font-black text-slate-800 font-mono">
                  {decision.waterFlowRate}
                </span>
                <span className="text-xs font-bold text-emerald-700 font-mono">Liters / Minute</span>
              </div>
              <div className="mt-1 text-xs text-slate-600">
                Status: <span className="font-semibold text-emerald-800">{decision.status}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setActiveTab('pipeline')}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 transition cursor-pointer"
              >
                <span>Follow in Pipeline</span>
                <ArrowRight className="w-3.5 h-3.5 text-emerald-600" />
              </button>
              <button
                onClick={() => setActiveTab('arithmetic')}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition cursor-pointer"
              >
                <span>Arithmetic Tracer</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

