import { SensorData, IrrigationDecision } from '../types';

/**
 * Agronomic Irrigation Calculation Model for Smart Agriculture Processor
 * 
 * Formula:
 * Water Requirement (L/min) = 
 *   Base Requirement 
 *   + (Soil Moisture Deficit * Deficit Factor) 
 *   + (Temperature Factor * (Temp - Temp_Baseline)) 
 *   - (Humidity Factor * Humidity)
 */
export function calculateIrrigationDemand(sensor: SensorData): IrrigationDecision {
  const { soilMoisture, temperature, humidity, targetMoisture = 60, baseWaterRequirement = 8.0 } = sensor;

  // 1. Soil moisture deficit (0 if moisture >= target)
  const moistureDeficitPct = Math.max(0, targetMoisture - soilMoisture);
  // Deficit coefficient: 0.75 L/min per 1% moisture deficit below target
  const deficitComponent = Number((moistureDeficitPct * 0.75).toFixed(2));

  // 2. Temperature evaporation factor (baseline 20°C)
  const tempExcess = Math.max(0, temperature - 20);
  // Temp coefficient: 0.60 L/min per °C above baseline
  const tempComponent = Number((tempExcess * 0.60).toFixed(2));

  // 3. Humidity dampening offset (higher relative humidity reduces transpiration)
  // Humidity coefficient: 0.15 L/min reduction per 1% humidity
  const humidityComponent = Number(((humidity / 100) * 15.0).toFixed(2));

  // 4. Compute composite water flow demand
  let totalRawDemand = baseWaterRequirement + deficitComponent + tempComponent - humidityComponent;

  // If soil moisture is already high (> 65%), no irrigation is required
  let isRequired = false;
  let status: IrrigationDecision['status'] = 'Optimal - No Irrigation';

  if (soilMoisture > 75) {
    status = 'Over-saturated - Drainage Alert';
    totalRawDemand = 0;
    isRequired = false;
  } else if (soilMoisture < 35 || (soilMoisture < 50 && temperature > 32)) {
    status = 'Critical - Immediate Irrigation';
    isRequired = true;
    totalRawDemand = Math.max(15, totalRawDemand);
  } else if (soilMoisture < targetMoisture && totalRawDemand > 5) {
    status = 'Moderate Irrigation Required';
    isRequired = true;
  } else {
    status = 'Optimal - No Irrigation';
    totalRawDemand = 0;
    isRequired = false;
  }

  const finalFlowRate = isRequired ? Number(Math.max(2.0, Math.min(65.0, totalRawDemand)).toFixed(2)) : 0;

  return {
    required: isRequired,
    waterFlowRate: finalFlowRate,
    soilMoistureDeficit: moistureDeficitPct,
    tempFactor: tempExcess,
    humidityFactor: humidity,
    rawScore: Number(totalRawDemand.toFixed(2)),
    status,
    formulaBreakdown: {
      base: baseWaterRequirement,
      deficitComponent,
      tempComponent,
      humidityComponent,
      total: Number(totalRawDemand.toFixed(2)),
    },
  };
}

export function getMoistureStatus(val: number): { label: string; color: string; bg: string } {
  if (val < 30) return { label: 'Critically Dry', color: 'text-rose-400', bg: 'bg-rose-500/20 border-rose-500/30' };
  if (val < 45) return { label: 'Dry', color: 'text-amber-400', bg: 'bg-amber-500/20 border-amber-500/30' };
  if (val <= 70) return { label: 'Optimal', color: 'text-emerald-400', bg: 'bg-emerald-500/20 border-emerald-500/30' };
  return { label: 'Saturated', color: 'text-blue-400', bg: 'bg-blue-500/20 border-blue-500/30' };
}

export function getTemperatureStatus(val: number): { label: string; color: string; bg: string } {
  if (val < 15) return { label: 'Cold / Frost Risk', color: 'text-cyan-400', bg: 'bg-cyan-500/20 border-cyan-500/30' };
  if (val <= 28) return { label: 'Optimal Growing', color: 'text-emerald-400', bg: 'bg-emerald-500/20 border-emerald-500/30' };
  if (val <= 36) return { label: 'High Heat', color: 'text-amber-400', bg: 'bg-amber-500/20 border-amber-500/30' };
  return { label: 'Extreme Heatwave', color: 'text-rose-400', bg: 'bg-rose-500/20 border-rose-500/30' };
}

export function getHumidityStatus(val: number): { label: string; color: string; bg: string } {
  if (val < 30) return { label: 'Arid / Low', color: 'text-amber-400', bg: 'bg-amber-500/20 border-amber-500/30' };
  if (val <= 65) return { label: 'Normal / Ideal', color: 'text-emerald-400', bg: 'bg-emerald-500/20 border-emerald-500/30' };
  return { label: 'Humid / Mildew Risk', color: 'text-indigo-400', bg: 'bg-indigo-500/20 border-indigo-500/30' };
}
