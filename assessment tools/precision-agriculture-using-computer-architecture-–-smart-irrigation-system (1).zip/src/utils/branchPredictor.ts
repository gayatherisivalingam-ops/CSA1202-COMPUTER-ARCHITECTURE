export type BranchState = '00' | '01' | '10' | '11'; 
// 00: Strongly Not Taken (SNT)
// 01: Weakly Not Taken (WNT)
// 10: Weakly Taken (WT)
// 11: Strongly Taken (ST)

export interface BranchHistoryItem {
  cycleIndex: number;
  sensorSoilMoisture: number;
  temperature: number;
  actualOutcome: 'TAKEN' | 'NOT_TAKEN';
  alwaysTakenPrediction: 'TAKEN' | 'NOT_TAKEN';
  alwaysNotTakenPrediction: 'TAKEN' | 'NOT_TAKEN';
  oneBitPrediction: 'TAKEN' | 'NOT_TAKEN';
  twoBitPrediction: 'TAKEN' | 'NOT_TAKEN';
  twoBitStateBefore: BranchState;
  twoBitStateAfter: BranchState;
  isTwoBitCorrect: boolean;
}

export interface BranchEvaluationResult {
  history: BranchHistoryItem[];
  alwaysTakenAccuracy: number;
  alwaysNotTakenAccuracy: number;
  oneBitAccuracy: number;
  twoBitAccuracy: number;
  totalBranches: number;
  mispredictionPenaltyCycles: number;
}

export const STATE_LABELS: Record<BranchState, string> = {
  '00': 'Strongly Not Taken (00)',
  '01': 'Weakly Not Taken (01)',
  '10': 'Weakly Taken (10)',
  '11': 'Strongly Taken (11)',
};

/**
 * Next state transition logic for 2-bit saturating counter
 */
export function getNext2BitState(currentState: BranchState, outcome: 'TAKEN' | 'NOT_TAKEN'): BranchState {
  if (outcome === 'TAKEN') {
    switch (currentState) {
      case '00': return '01';
      case '01': return '10';
      case '10': return '11';
      case '11': return '11';
    }
  } else {
    switch (currentState) {
      case '11': return '10';
      case '10': return '01';
      case '01': return '00';
      case '00': return '00';
    }
  }
}

/**
 * Predicts based on 2-bit state (MSB = 1 -> Taken, MSB = 0 -> Not Taken)
 */
export function predictFrom2BitState(state: BranchState): 'TAKEN' | 'NOT_TAKEN' {
  return state === '10' || state === '11' ? 'TAKEN' : 'NOT_TAKEN';
}

/**
 * Simulates a realistic sequence of 15 irrigation decision cycles (e.g. over a 24-hour diurnal cycle)
 */
export function simulateBranchPredictionSequence(initialMoisture: number = 35): BranchEvaluationResult {
  // Realistic sensor sequence simulating morning dry spell -> noon peak heat -> evening sprinkler cycle -> night damp
  const testSequence = [
    { soil: 32, temp: 28 }, // Early morning dry -> Taken
    { soil: 30, temp: 31 }, // Mid morning -> Taken
    { soil: 28, temp: 34 }, // Noon high heat -> Taken
    { soil: 25, temp: 36 }, // Peak heat -> Taken
    { soil: 55, temp: 33 }, // Post-irrigation 1 -> Not Taken
    { soil: 58, temp: 30 }, // Afternoon optimal -> Not Taken
    { soil: 56, temp: 29 }, // Late afternoon -> Not Taken
    { soil: 52, temp: 27 }, // Dusk -> Not Taken
    { soil: 48, temp: 25 }, // Evening evaporation -> Not Taken
    { soil: 40, temp: 24 }, // Night soil drying -> Taken
    { soil: 38, temp: 23 }, // Late night -> Taken
    { soil: 35, temp: 22 }, // Dawn dry -> Taken
    { soil: 62, temp: 24 }, // Morning watering -> Not Taken
    { soil: 65, temp: 26 }, // Optimal loam -> Not Taken
    { soil: 60, temp: 28 }, // Daytime optimal -> Not Taken
  ];

  let current2BitState: BranchState = '10'; // Start with Weakly Taken
  let current1BitState: 'TAKEN' | 'NOT_TAKEN' = 'TAKEN';

  const history: BranchHistoryItem[] = [];

  let alwaysTakenHits = 0;
  let alwaysNotTakenHits = 0;
  let oneBitHits = 0;
  let twoBitHits = 0;

  testSequence.forEach((item, idx) => {
    // Actual outcome: Irrigation is required if soil < 42% or (soil < 50% and temp > 30°C)
    const actual: 'TAKEN' | 'NOT_TAKEN' = (item.soil < 42 || (item.soil < 50 && item.temp > 30)) ? 'TAKEN' : 'NOT_TAKEN';

    const atPred: 'TAKEN' | 'NOT_TAKEN' = 'TAKEN';
    const antPred: 'TAKEN' | 'NOT_TAKEN' = 'NOT_TAKEN';
    const oneBitPred = current1BitState;
    const twoBitPred = predictFrom2BitState(current2BitState);

    if (atPred === actual) alwaysTakenHits++;
    if (antPred === actual) alwaysNotTakenHits++;
    if (oneBitPred === actual) oneBitHits++;
    if (twoBitPred === actual) twoBitHits++;

    const stateBefore = current2BitState;
    const stateAfter = getNext2BitState(current2BitState, actual);
    current2BitState = stateAfter;
    current1BitState = actual; // 1-bit predictor simply copies the last outcome

    history.push({
      cycleIndex: idx + 1,
      sensorSoilMoisture: item.soil,
      temperature: item.temp,
      actualOutcome: actual,
      alwaysTakenPrediction: atPred,
      alwaysNotTakenPrediction: antPred,
      oneBitPrediction: oneBitPred,
      twoBitPrediction: twoBitPred,
      twoBitStateBefore: stateBefore,
      twoBitStateAfter: stateAfter,
      isTwoBitCorrect: twoBitPred === actual,
    });
  });

  const total = testSequence.length;

  return {
    history,
    alwaysTakenAccuracy: Number(((alwaysTakenHits / total) * 100).toFixed(1)),
    alwaysNotTakenAccuracy: Number(((alwaysNotTakenHits / total) * 100).toFixed(1)),
    oneBitAccuracy: Number(((oneBitHits / total) * 100).toFixed(1)),
    twoBitAccuracy: Number(((twoBitHits / total) * 100).toFixed(1)),
    totalBranches: total,
    mispredictionPenaltyCycles: 2, // 2-cycle penalty per branch misprediction in standard 5-stage pipeline
  };
}
