import React from 'react';
import {
  Gauge,
  Zap,
  Clock,
  Activity,
  Layers,
  Sparkles,
  Cpu,
  Droplet,
  Sun,
  Flame,
  CheckCircle2,
  TrendingDown,
  TrendingUp,
  HelpCircle,
  Leaf,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Cell,
} from 'recharts';
import { PerformanceMetrics, SensorData } from '../../types';
import { MetricCard } from '../common/MetricCard';

interface PerformanceEvaluationViewProps {
  metrics: PerformanceMetrics;
  sensor: SensorData;
}

export const PerformanceEvaluationView: React.FC<PerformanceEvaluationViewProps> = ({
  metrics,
  sensor,
}) => {
  // Chart 1: Comparison Bar Chart (Cycles & Stalls)
  const comparisonData = [
    {
      metric: 'Execution Cycles',
      Unoptimized: metrics.unoptimizedCycles,
      Optimized: metrics.optimizedCycles,
    },
    {
      metric: 'Stall / Flush Cycles',
      Unoptimized: metrics.unoptimizedStalls,
      Optimized: metrics.optimizedStalls,
    },
    {
      metric: 'Latency (x10 ns)',
      Unoptimized: Math.round(metrics.unoptimizedLatency / 10),
      Optimized: Math.round(metrics.optimizedLatency / 10),
    },
  ];

  // Chart 2: CPI Line Chart across simulated instruction loads (5 to 30 instructions)
  const cpiProgressionData = [
    { instructions: 5, UnoptimizedCPI: 2.8, OptimizedCPI: 1.6 },
    { instructions: 10, UnoptimizedCPI: 2.45, OptimizedCPI: 1.35 },
    { instructions: 15, UnoptimizedCPI: 2.3, OptimizedCPI: 1.22 },
    { instructions: 20, UnoptimizedCPI: 2.2, OptimizedCPI: 1.15 },
    { instructions: 30, UnoptimizedCPI: 2.1, OptimizedCPI: 1.08 },
  ];

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
              <Gauge className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 tracking-tight">
              Pipeline Performance Evaluation & Optimization Gains
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Quantitative analysis of architectural techniques: Forwarding bypass, Load-Use interlocks, Dynamic Branch Prediction, and Split Cache.
          </p>
        </div>

        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 font-mono text-xs font-bold self-start md:self-auto">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>Amdahl's Speedup: <strong className="text-emerald-950">{metrics.speedup}x</strong></span>
        </div>
      </div>

      {/* 4 High-Impact KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <MetricCard
          id="perf-cpi-card"
          title="Cycles Per Instruction (CPI)"
          value={metrics.optimizedCPI}
          subValue={`vs ${metrics.unoptimizedCPI} unopt`}
          badge={`-${((metrics.unoptimizedCPI - metrics.optimizedCPI) / metrics.unoptimizedCPI * 100).toFixed(0)}%`}
          icon={Activity}
          color="emerald"
          description="Ideal CPI = 1.0"
        />

        <MetricCard
          id="perf-speedup-card"
          title="Processor Speedup"
          value={`${metrics.speedup}x`}
          subValue="Execution Gain"
          badge="Amdahl Model"
          icon={Zap}
          color="amber"
          description="T_unopt / T_opt"
        />

        <MetricCard
          id="perf-throughput-card"
          title="Instruction Throughput"
          value={metrics.optimizedThroughput}
          subValue="Inst / Cycle"
          badge={`+${((metrics.optimizedThroughput - metrics.unoptimizedThroughput) / metrics.unoptimizedThroughput * 100).toFixed(0)}%`}
          icon={TrendingUp}
          color="teal"
          description="Instructions retired/cycle"
        />

        <MetricCard
          id="perf-stall-reduction-card"
          title="Stall Reduction"
          value={`${metrics.stallReductionPercent}%`}
          subValue={`${metrics.optimizedStalls} vs ${metrics.unoptimizedStalls} stalls`}
          badge="Bypass Gain"
          icon={Layers}
          color="purple"
          description="Hazard bubbles eliminated"
        />
      </div>

      {/* Side-by-Side Detailed Breakdown Table */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <span>Comparative Metrics Matrix (Unoptimized vs Optimized)</span>
        </h3>

        <div className="overflow-x-auto rounded-lg border border-slate-200">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[9px] border-b border-slate-200">
              <tr>
                <th className="p-2.5">Performance Dimension</th>
                <th className="p-2.5 text-rose-700">Without Optimization (Baseline)</th>
                <th className="p-2.5 text-emerald-800">With Optimization (Bypass + Branch Pred)</th>
                <th className="p-2.5 text-slate-700">Quantitative Improvement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              <tr className="hover:bg-slate-50 transition">
                <td className="p-2.5 font-bold text-slate-800">Total Execution Cycles</td>
                <td className="p-2.5 text-rose-700 font-bold">{metrics.unoptimizedCycles} Cycles</td>
                <td className="p-2.5 text-emerald-800 font-bold">{metrics.optimizedCycles} Cycles</td>
                <td className="p-2.5 text-emerald-700 font-bold">{metrics.unoptimizedCycles - metrics.optimizedCycles} Cycles Saved</td>
              </tr>
              <tr className="hover:bg-slate-50 transition">
                <td className="p-2.5 font-bold text-slate-800">Cycles Per Instruction (CPI)</td>
                <td className="p-2.5 text-rose-700 font-bold">{metrics.unoptimizedCPI}</td>
                <td className="p-2.5 text-emerald-800 font-bold">{metrics.optimizedCPI}</td>
                <td className="p-2.5 text-emerald-700 font-bold">
                  {((metrics.unoptimizedCPI - metrics.optimizedCPI) / metrics.unoptimizedCPI * 100).toFixed(1)}% Lower CPI
                </td>
              </tr>
              <tr className="hover:bg-slate-50 transition">
                <td className="p-2.5 font-bold text-slate-800">Throughput (Instructions / Cycle)</td>
                <td className="p-2.5 text-rose-700 font-bold">{metrics.unoptimizedThroughput} IPC</td>
                <td className="p-2.5 text-emerald-800 font-bold">{metrics.optimizedThroughput} IPC</td>
                <td className="p-2.5 text-emerald-700 font-bold">
                  {((metrics.optimizedThroughput - metrics.unoptimizedThroughput) / metrics.unoptimizedThroughput * 100).toFixed(1)}% Faster Throughput
                </td>
              </tr>
              <tr className="hover:bg-slate-50 transition">
                <td className="p-2.5 font-bold text-slate-800">Execution Latency (@ 50 MHz)</td>
                <td className="p-2.5 text-rose-700 font-bold">{metrics.unoptimizedLatency} ns</td>
                <td className="p-2.5 text-emerald-800 font-bold">{metrics.optimizedLatency} ns</td>
                <td className="p-2.5 text-emerald-700 font-bold">{metrics.unoptimizedLatency - metrics.optimizedLatency} ns Faster</td>
              </tr>
              <tr className="hover:bg-slate-50 transition">
                <td className="p-2.5 font-bold text-slate-800">Pipeline Stalls & Flushes</td>
                <td className="p-2.5 text-rose-700 font-bold">{metrics.unoptimizedStalls} Stalls</td>
                <td className="p-2.5 text-emerald-800 font-bold">{metrics.optimizedStalls} Stall (Load-Use only)</td>
                <td className="p-2.5 text-purple-700 font-bold">{metrics.stallReductionPercent}% Stall Elimination</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Dual Recharts Visualizations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Bar Chart: Cycles & Latency Comparison */}
        <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <span>Hardware Execution Overhead Comparison</span>
          </h3>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={comparisonData} margin={{ top: 15, right: 15, left: -15, bottom: 15 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="metric" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#cbd5e1',
                    borderRadius: '0.5rem',
                    color: '#0f172a',
                    fontFamily: 'monospace',
                    fontSize: '11px',
                    boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: 11, paddingTop: 4 }} />
                <Bar dataKey="Unoptimized" fill="#f43f5e" radius={[4, 4, 0, 0]} name="Unoptimized (Stalled)" />
                <Bar dataKey="Optimized" fill="#059669" radius={[4, 4, 0, 0]} name="Optimized (Bypass + FSM)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Line Chart: CPI Progression */}
        <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <span>CPI Asymptotic Convergence (Ideal CPI ➔ 1.0)</span>
          </h3>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={cpiProgressionData} margin={{ top: 15, right: 15, left: -15, bottom: 15 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="instructions" stroke="#64748b" fontSize={10} unit=" Inst" />
                <YAxis stroke="#64748b" fontSize={10} domain={[1.0, 3.0]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#cbd5e1',
                    borderRadius: '0.5rem',
                    color: '#0f172a',
                    fontFamily: 'monospace',
                    fontSize: '11px',
                    boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: 11, paddingTop: 4 }} />
                <Line
                  type="monotone"
                  dataKey="UnoptimizedCPI"
                  stroke="#f43f5e"
                  strokeWidth={2}
                  name="Unoptimized CPI"
                  dot={{ r: 3 }}
                />
                <Line
                  type="monotone"
                  dataKey="OptimizedCPI"
                  stroke="#059669"
                  strokeWidth={2}
                  name="Optimized CPI"
                  dot={{ r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* SECTION 11: WATER & ENERGY IMPACT */}
      <div className="p-4 sm:p-6 rounded-xl bg-white border border-emerald-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200">
            <Leaf className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800">
              Water & Energy Impact Analysis (Processor vs Agronomic Physics)
            </h3>
            <p className="text-xs text-slate-500">
              Rigorous differentiation between digital compute energy savings and real agricultural water conservation.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
          {/* Before Optimization Box */}
          <div className="p-4 rounded-lg bg-rose-50/50 border border-rose-200 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-rose-800 font-bold uppercase flex items-center gap-1.5 text-[11px]">
                <Cpu className="w-3.5 h-3.5" /> Before Optimization
              </span>
              <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 text-[9px] font-bold">High Overhead</span>
            </div>

            <ul className="space-y-1.5 text-slate-600 text-[11px] list-disc list-inside leading-relaxed">
              <li>
                <strong className="text-slate-800">Idle Clock Wasted: </strong>
                {metrics.unoptimizedStalls} stall cycles where hardware ALUs and buses consume static leakage power without retiring instructions.
              </li>
              <li>
                <strong className="text-slate-800">Higher Decision Latency: </strong>
                {metrics.unoptimizedLatency} ns execution window per sensing epoch slows closed-loop response to rapid soil drying during heatwaves.
              </li>
              <li>
                <strong className="text-slate-800">Instruction Pipeline Bubbles: </strong>
                Unnecessary memory bus contentions cause frequent CPU thread stalls.
              </li>
            </ul>
          </div>

          {/* After Optimization Box */}
          <div className="p-4 rounded-lg bg-emerald-50/50 border border-emerald-200 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-emerald-800 font-bold uppercase flex items-center gap-1.5 text-[11px]">
                <Zap className="w-3.5 h-3.5" /> After Optimization
              </span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[9px] font-bold">Optimal Utilization</span>
            </div>

            <ul className="space-y-1.5 text-slate-600 text-[11px] list-disc list-inside leading-relaxed">
              <li>
                <strong className="text-slate-800">Reduced Duty Cycle: </strong>
                Execution finished in {metrics.optimizedCycles} cycles allows CPU core to enter ultra-low-power sleep states faster.
              </li>
              <li>
                <strong className="text-slate-800">Compute Energy Saved: </strong>
                Estimated ~{metrics.estimatedCpuEnergySavedPct}% reduction in compute energy per sensor sampling cycle.
              </li>
              <li>
                <strong className="text-slate-800">Precise Irrigation Metering: </strong>
                Low latency actuation prevents over-irrigation runoff and saves up to 30-40% field water through timely solenoid valve shutoff.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

