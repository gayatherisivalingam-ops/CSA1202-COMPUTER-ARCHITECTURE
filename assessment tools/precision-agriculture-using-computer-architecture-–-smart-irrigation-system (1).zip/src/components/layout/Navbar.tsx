import React from 'react';
import {
  Sprout,
  Cpu,
  Play,
  RotateCcw,
  Sparkles,
  Zap,
  Activity,
  Flame,
  CloudRain,
  Sun,
  Droplets,
} from 'lucide-react';
import { SensorData, IrrigationDecision, PerformanceMetrics } from '../../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  sensor: SensorData;
  setSensor: React.Dispatch<React.SetStateAction<SensorData>>;
  decision: IrrigationDecision;
  metrics: PerformanceMetrics;
  onRunSimulation: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  sensor,
  setSensor,
  decision,
  metrics,
  onRunSimulation,
}) => {
  const applyPreset = (soil: number, temp: number, hum: number, name: string) => {
    setSensor((prev) => ({
      ...prev,
      soilMoisture: soil,
      temperature: temp,
      humidity: hum,
    }));
  };

  const handleResetDatapath = () => {
    setSensor({
      soilMoisture: 35,
      temperature: 31,
      humidity: 58,
      targetMoisture: 60,
      baseWaterRequirement: 8.0,
    });
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 px-4 lg:px-8 py-2.5 transition-all text-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Title and Module Information */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-xs">
              <Sprout className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800 text-sm sm:text-base leading-tight">
                Smart Irrigation Simulator // <span className="text-emerald-600 font-medium">Control Panel</span>
              </h2>
              <p className="text-[11px] text-slate-400 font-medium">
                MIPS 5-Stage Pipelined Processor Implementation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={onRunSimulation}
              className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 text-white text-xs font-bold rounded shadow-xs hover:bg-emerald-700"
            >
              <Play className="w-3 h-3 fill-current" />
              Run
            </button>
          </div>
        </div>

        {/* Quick Presets & Status Indicators */}
        <div className="flex items-center gap-2 flex-wrap justify-center sm:justify-end w-full md:w-auto">
          {/* Quick Presets */}
          <div className="hidden xl:flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg p-1 text-xs">
            <span className="text-slate-500 px-1.5 font-medium flex items-center gap-1 text-[11px]">
              <Sparkles className="w-3 h-3 text-emerald-600" /> Presets:
            </span>
            <button
              onClick={() => applyPreset(25, 36, 30, 'Drought')}
              className={`px-2 py-0.5 rounded text-xs transition cursor-pointer ${
                sensor.soilMoisture === 25 && sensor.temperature === 36
                  ? 'bg-rose-100 text-rose-700 font-bold border border-rose-200'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
              title="25% Moisture, 36°C Temp, 30% Humidity"
            >
              <span className="flex items-center gap-1">
                <Flame className="w-3 h-3 text-rose-500" /> Drought
              </span>
            </button>
            <button
              onClick={() => applyPreset(35, 31, 58, 'Standard')}
              className={`px-2 py-0.5 rounded text-xs transition cursor-pointer ${
                sensor.soilMoisture === 35 && sensor.temperature === 31
                  ? 'bg-emerald-100 text-emerald-800 font-bold border border-emerald-300'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
              title="35% Moisture, 31°C Temp, 58% Humidity"
            >
              <span className="flex items-center gap-1">
                <Sun className="w-3 h-3 text-amber-500" /> Standard
              </span>
            </button>
            <button
              onClick={() => applyPreset(78, 22, 85, 'Monsoon')}
              className={`px-2 py-0.5 rounded text-xs transition cursor-pointer ${
                sensor.soilMoisture === 78 && sensor.temperature === 22
                  ? 'bg-blue-100 text-blue-800 font-bold border border-blue-300'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
              title="78% Moisture, 22°C Temp, 85% Humidity"
            >
              <span className="flex items-center gap-1">
                <CloudRain className="w-3 h-3 text-blue-500" /> Monsoon
              </span>
            </button>
          </div>

          {/* Actuator Flow Status Badge */}
          <div
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-xs font-semibold ${
              decision.required
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                : 'bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                decision.required ? 'bg-emerald-500 shadow-xs' : 'bg-slate-400'
              }`}
            />
            <span>
              Valve: <strong className="font-mono">{decision.required ? `${decision.waterFlowRate} L/min` : 'OFF'}</strong>
            </span>
          </div>

          {/* Speedup Badge */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-50 border border-slate-200 text-slate-700 text-xs font-mono">
            <Zap className="w-3 h-3 text-emerald-600" />
            <span>Speedup: <strong className="text-emerald-700">{metrics.speedup}x</strong></span>
          </div>

          {/* Action Buttons */}
          <div className="hidden md:flex items-center gap-2">
            <button
              id="desktop-run-simulation-btn"
              onClick={onRunSimulation}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded shadow-xs transition flex items-center gap-1.5 cursor-pointer"
            >
              <Play className="w-3 h-3 fill-current" />
              RUN SIMULATION
            </button>

            <button
              onClick={handleResetDatapath}
              className="px-3.5 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold rounded transition flex items-center gap-1.5 cursor-pointer"
              title="Reset sensor registers to standard baseline"
            >
              <RotateCcw className="w-3 h-3 text-slate-500" />
              RESET DATAPATH
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

