import { BoothStep, DivisionStep, IEEE754Breakdown } from '../types';

/**
 * Helper to convert integer to N-bit two's complement binary string
 */
export function toTwosComplement(num: number, bits: number): string {
  let val = num;
  if (val < 0) {
    val = (1 << bits) + val;
  }
  return (val >>> 0).toString(2).padStart(bits, '0').slice(-bits);
}

/**
 * Helper to parse binary two's complement to signed integer
 */
export function fromTwosComplement(bin: string): number {
  const isNegative = bin[0] === '1';
  if (!isNegative) {
    return parseInt(bin, 2);
  }
  const bits = bin.length;
  const raw = parseInt(bin, 2);
  return raw - (1 << bits);
}

/**
 * Booth's Multiplication Algorithm Step Generator (8-bit or 5-bit)
 * Multiplies Multiplicand (M) by Multiplier (Q)
 */
export function generateBoothMultiplication(multiplicand: number, multiplier: number, bits: number = 5): {
  steps: BoothStep[];
  multiplicand: number;
  multiplier: number;
  result: number;
  mBinary: string;
  qBinary: string;
  resultBinary: string;
} {
  // Clamp input values to fit in signed bits range
  const minVal = -(1 << (bits - 1));
  const maxVal = (1 << (bits - 1)) - 1;
  const M_val = Math.max(minVal, Math.min(maxVal, multiplicand));
  const Q_val = Math.max(minVal, Math.min(maxVal, multiplier));

  const M_bin = toTwosComplement(M_val, bits);
  const negM_val = -M_val;
  const negM_bin = toTwosComplement(negM_val, bits);

  let A_bin = '0'.repeat(bits);
  let Q_bin = toTwosComplement(Q_val, bits);
  let Q_prev = '0';
  let count = bits;

  const steps: BoothStep[] = [];

  // Initial step
  steps.push({
    step: 0,
    action: 'Initialization (A=0, Q=Multiplier, Q-1=0, M=Multiplicand)',
    A: A_bin,
    Q: Q_bin,
    Q_prev: Q_prev,
    M: M_bin,
    count: count,
    decimalAccumulator: fromTwosComplement(A_bin + Q_bin),
  });

  for (let i = 1; i <= bits; i++) {
    const q0 = Q_bin[Q_bin.length - 1];
    const pair = q0 + Q_prev;
    let actionDesc = '';

    if (pair === '10') {
      // A = A - M
      const aVal = fromTwosComplement(A_bin);
      const newAVal = aVal - M_val;
      A_bin = toTwosComplement(newAVal, bits);
      actionDesc = `Q₀Q₋₁=10 ➔ A = A - M (${aVal} - ${M_val} = ${newAVal})`;
      steps.push({
        step: i,
        action: actionDesc,
        A: A_bin,
        Q: Q_bin,
        Q_prev: Q_prev,
        M: M_bin,
        count: count,
        decimalAccumulator: fromTwosComplement(A_bin + Q_bin),
      });
    } else if (pair === '01') {
      // A = A + M
      const aVal = fromTwosComplement(A_bin);
      const newAVal = aVal + M_val;
      A_bin = toTwosComplement(newAVal, bits);
      actionDesc = `Q₀Q₋₁=01 ➔ A = A + M (${aVal} + ${M_val} = ${newAVal})`;
      steps.push({
        step: i,
        action: actionDesc,
        A: A_bin,
        Q: Q_bin,
        Q_prev: Q_prev,
        M: M_bin,
        count: count,
        decimalAccumulator: fromTwosComplement(A_bin + Q_bin),
      });
    } else {
      actionDesc = `Q₀Q₋₁=${pair} ➔ No arithmetic operation`;
      steps.push({
        step: i,
        action: actionDesc,
        A: A_bin,
        Q: Q_bin,
        Q_prev: Q_prev,
        M: M_bin,
        count: count,
        decimalAccumulator: fromTwosComplement(A_bin + Q_bin),
      });
    }

    // Arithmetic Right Shift (ARS) of [A, Q, Q_prev]
    const combined = A_bin + Q_bin + Q_prev;
    const msb = combined[0]; // Sign bit retained for arithmetic shift
    const shifted = msb + combined.slice(0, -1);

    A_bin = shifted.slice(0, bits);
    Q_bin = shifted.slice(bits, bits * 2);
    Q_prev = shifted[shifted.length - 1];
    count--;

    steps.push({
      step: i,
      action: `Arithmetic Right Shift (ARS [A, Q, Q₋₁]), Count = ${count}`,
      A: A_bin,
      Q: Q_bin,
      Q_prev: Q_prev,
      M: M_bin,
      count: count,
      decimalAccumulator: fromTwosComplement(A_bin + Q_bin),
    });
  }

  const finalResultBin = A_bin + Q_bin;
  const finalResultDec = fromTwosComplement(finalResultBin);

  return {
    steps,
    multiplicand: M_val,
    multiplier: Q_val,
    result: finalResultDec,
    mBinary: M_bin,
    qBinary: toTwosComplement(Q_val, bits),
    resultBinary: finalResultBin,
  };
}

/**
 * Restoring Division Algorithm (Unsigned)
 * Dividend (Q) / Divisor (M)
 */
export function generateRestoringDivision(dividend: number, divisor: number, bits: number = 5): {
  steps: DivisionStep[];
  dividend: number;
  divisor: number;
  quotient: number;
  remainder: number;
  qBinary: string;
  mBinary: string;
} {
  const maxVal = (1 << bits) - 1;
  const Q_val = Math.max(0, Math.min(maxVal, Math.abs(dividend)));
  const M_val = Math.max(1, Math.min(maxVal, Math.abs(divisor))); // prevent div by zero

  let A_bin = '0'.repeat(bits + 1); // 1 extra bit for sign/carry
  let Q_bin = Q_val.toString(2).padStart(bits, '0');
  const M_bin = M_val.toString(2).padStart(bits + 1, '0');
  let count = bits;

  const steps: DivisionStep[] = [];

  steps.push({
    step: 0,
    action: 'Initialization (A=0, Q=Dividend, M=Divisor)',
    A: A_bin,
    Q: Q_bin,
    M: M_bin,
    count: count,
    restored: false,
    comment: `Dividend Q = ${Q_val} (${Q_bin}), Divisor M = ${M_val} (${M_bin})`,
  });

  for (let i = 1; i <= bits; i++) {
    // 1. Shift Left [A, Q]
    const combined = A_bin.slice(1) + Q_bin;
    const shiftedA = combined.slice(0, bits + 1);
    let shiftedQ = combined.slice(bits + 1) + '_'; // bit to be determined

    steps.push({
      step: i,
      action: 'Shift Left [A, Q]',
      A: shiftedA,
      Q: shiftedQ,
      M: M_bin,
      count: count,
      restored: false,
      comment: 'Left shift accumulator and dividend register by 1 bit',
    });

    // 2. Subtract M from A (A = A - M)
    const currentAVal = parseInt(shiftedA, 2);
    const subResult = currentAVal - M_val;
    const isNegative = subResult < 0;

    let subA_bin = isNegative
      ? (1 << (bits + 1)) + subResult
      : subResult;
    let subA_str = (subA_bin >>> 0).toString(2).padStart(bits + 1, '0').slice(-(bits + 1));

    if (isNegative) {
      // 3. Restore A (A = A + M) and set Q0 = 0
      shiftedQ = shiftedQ.slice(0, -1) + '0';
      A_bin = shiftedA; // Restored to previous value
      count--;
      steps.push({
        step: i,
        action: `A = A - M (${subResult} < 0) ➔ Restore A, Q₀ = 0`,
        A: A_bin,
        Q: shiftedQ,
        M: M_bin,
        count: count,
        restored: true,
        comment: `Subtraction yielded negative (<0). Restored A to ${shiftedA}. Set Q₀=0. Count=${count}`,
      });
    } else {
      // Successful subtraction, keep A and set Q0 = 1
      shiftedQ = shiftedQ.slice(0, -1) + '1';
      A_bin = subA_str;
      count--;
      steps.push({
        step: i,
        action: `A = A - M (${subResult} ≥ 0) ➔ Keep A, Q₀ = 1`,
        A: A_bin,
        Q: shiftedQ,
        M: M_bin,
        count: count,
        restored: false,
        comment: `Subtraction positive. Stored A=${subA_str}. Set Q₀=1. Count=${count}`,
      });
    }

    Q_bin = shiftedQ;
  }

  const finalQuotient = parseInt(Q_bin, 2);
  const finalRemainder = parseInt(A_bin, 2);

  return {
    steps,
    dividend: Q_val,
    divisor: M_val,
    quotient: finalQuotient,
    remainder: finalRemainder,
    qBinary: Q_bin,
    mBinary: M_val.toString(2).padStart(bits, '0'),
  };
}

/**
 * IEEE 754 Single-Precision (32-bit) Floating-Point Analyzer
 */
export function analyzeIEEE754(num: number): IEEE754Breakdown {
  if (isNaN(num)) {
    return {
      value: NaN,
      signBit: '0',
      exponentBits: '11111111',
      biasedExponent: 255,
      unbiasedExponent: NaN,
      mantissaBits: '10000000000000000000000',
      storedMantissaBits: '10000000000000000000000',
      hex: '0x7FC00000',
      binary32: '0 11111111 10000000000000000000000',
      exactReconstructed: NaN,
      type: 'nan',
    };
  }

  if (num === Infinity || num === -Infinity) {
    const sign = num < 0 ? '1' : '0';
    return {
      value: num,
      signBit: sign,
      exponentBits: '11111111',
      biasedExponent: 255,
      unbiasedExponent: Infinity,
      mantissaBits: '00000000000000000000000',
      storedMantissaBits: '00000000000000000000000',
      hex: sign === '1' ? '0xFF800000' : '0x7F800000',
      binary32: `${sign} 11111111 00000000000000000000000`,
      exactReconstructed: num,
      type: 'infinity',
    };
  }

  // Use Float32Array and Uint32Array for exact IEEE 754 bit extraction
  const float32 = new Float32Array(1);
  float32[0] = num;
  const uint32 = new Uint32Array(float32.buffer);
  const bitVal = uint32[0];

  const fullBin = bitVal.toString(2).padStart(32, '0');
  const signBit = fullBin[0];
  const exponentBits = fullBin.slice(1, 9);
  const storedMantissaBits = fullBin.slice(9);
  const biasedExponent = parseInt(exponentBits, 2);
  const unbiasedExponent = biasedExponent - 127;

  let type: IEEE754Breakdown['type'] = 'normalized';
  let mantissaBits = '1.' + storedMantissaBits;

  if (biasedExponent === 0) {
    if (parseInt(storedMantissaBits, 2) === 0) {
      type = 'zero';
      mantissaBits = '0.00000000000000000000000';
    } else {
      type = 'denormalized';
      mantissaBits = '0.' + storedMantissaBits;
    }
  }

  const hex = '0x' + bitVal.toString(16).toUpperCase().padStart(8, '0');
  const binary32 = `${signBit} ${exponentBits} ${storedMantissaBits}`;

  return {
    value: float32[0],
    signBit,
    exponentBits,
    biasedExponent,
    unbiasedExponent,
    mantissaBits,
    storedMantissaBits,
    hex,
    binary32,
    exactReconstructed: float32[0],
    type,
  };
}

/**
 * Fixed-point Q8.8 conversion (8 integer bits, 8 fraction bits)
 */
export function toQ8_8(val: number): { raw: number; binary: string; hex: string; reconstructed: number } {
  const scaled = Math.round(val * 256);
  const clamped = Math.max(-32768, Math.min(32767, scaled));
  const bin = toTwosComplement(clamped, 16);
  const hex = '0x' + ((clamped < 0 ? (1 << 16) + clamped : clamped) >>> 0).toString(16).toUpperCase().padStart(4, '0');
  return {
    raw: clamped,
    binary: `${bin.slice(0, 8)}.${bin.slice(8)}`,
    hex,
    reconstructed: clamped / 256,
  };
}
