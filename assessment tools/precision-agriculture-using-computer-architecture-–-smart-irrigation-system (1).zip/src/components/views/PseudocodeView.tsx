import React, { useState } from 'react';
import { Code2, Copy, Check, Sparkles, FileCode, Terminal } from 'lucide-react';

export const PseudocodeView: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const fullPseudocode = `// =========================================================================
// SMART IRRIGATION SYSTEM USING PIPELINED PROCESSOR COMPUTER ARCHITECTURE
// Course: CSA1202 – Computer Architecture | Target: 5-Stage RISC Datapath
// =========================================================================

// -------------------------------------------------------------------------
// 1. SENSOR DATA ACQUISITION & REPRESENTATION
// -------------------------------------------------------------------------
PROCEDURE AcquireSensors():
    soil_moisture  = Read_ADC_Channel(0x2000)  // [0..100%] in R1
    temperature    = Read_ADC_Channel(0x2004)  // [0..50°C] in R2
    humidity       = Read_ADC_Channel(0x2008)  // [0..100%] in R3
    
    // Represent as Q8.8 Fixed-Point and IEEE-754 32-bit Float
    float_temp     = IEEE754_Convert(temperature)
    fixed_moist    = To_Q8_8(soil_moisture)
    RETURN (R1, R2, R3)
END PROCEDURE

// -------------------------------------------------------------------------
// 2. ARITHMETIC PROCESSING (BOOTH MULTIPLIER & RESTORING DIVIDER)
// -------------------------------------------------------------------------
FUNCTION BoothMultiply(M, Q, n_bits):
    A = 0, Q_prev = 0, Count = n_bits
    WHILE Count > 0 DO:
        pair = Concat(Q[0], Q_prev)
        IF pair == "10" THEN:
            A = A - M
        ELSE IF pair == "01" THEN:
            A = A + M
        END IF
        // Arithmetic Right Shift of [A, Q, Q_prev]
        (A, Q, Q_prev) = ArithmeticRightShift(A, Q, Q_prev)
        Count = Count - 1
    END WHILE
    RETURN Concat(A, Q)
END FUNCTION

FUNCTION RestoringDivide(Dividend, Divisor, n_bits):
    A = 0, Q = Dividend, M = Divisor, Count = n_bits
    WHILE Count > 0 DO:
        (A, Q) = ShiftLeft(A, Q)
        A = A - M
        IF A < 0 THEN:
            A = A + M    // Restore Accumulator
            Q[0] = 0
        ELSE:
            Q[0] = 1
        END IF
        Count = Count - 1
    END WHILE
    RETURN (Quotient = Q, Remainder = A)
END FUNCTION

// -------------------------------------------------------------------------
// 3. PIPELINE INSTRUCTION SET ARCHITECTURE (ISA) EXECUTION
// -------------------------------------------------------------------------
I1:  LOAD  R1, [0x2000]          // Read Soil Moisture ADC
I2:  LOAD  R2, [0x2004]          // Read Temperature ADC
I3:  LOAD  R3, [0x2008]          // Read Humidity ADC
I4:  SUB   R4, R_TARGET, R1      // Soil Deficit = Target(60%) - Moisture
I5:  MUL   R5, R2, R_TCOEFF      // Evaporation Factor = Temp * 0.60
I6:  ADD   R6, R4, R5            // Water Demand = Deficit + TempFactor
I7:  SUB   R6, R6, R3            // Dampen by Humidity: Demand - (Hum * 0.15)
I8:  CMP   R6, #0                // Compare demand against threshold #0
I9:  BGT   R6, IRRIGATION_ON     // Branch if Demand > 0
I10: STORE [0x3000], R6          // Actuate Solenoid Valve Flow Rate
I11: STORE [0x3004], R7          // Write Telemetry Status

// -------------------------------------------------------------------------
// 4. HAZARD DETECTION & FORWARDING UNIT LOGIC
// -------------------------------------------------------------------------
PROCEDURE ForwardingUnit(ID_EX, EX_MEM, MEM_WB):
    // EX Hazard Forwarding (ALU to ALU bypass)
    IF (EX_MEM.RegWrite AND (EX_MEM.RegisterRd != 0) 
        AND (EX_MEM.RegisterRd == ID_EX.RegisterRs1)) THEN:
        ForwardA = 10  // Forward from EX/MEM stage to ALU input 1
    END IF

    // MEM Hazard Forwarding
    IF (MEM_WB.RegWrite AND (MEM_WB.RegisterRd != 0)
        AND (MEM_WB.RegisterRd == ID_EX.RegisterRs1)) THEN:
        ForwardA = 01  // Forward from MEM/WB stage to ALU input 1
    END IF
END PROCEDURE

PROCEDURE HazardDetectionUnit(ID_EX, IF_ID):
    // Load-Use Data Hazard Detection
    IF (ID_EX.MemRead AND 
       ((ID_EX.RegisterRt == IF_ID.RegisterRs) OR 
        (ID_EX.RegisterRt == IF_ID.RegisterRt))) THEN:
        // Stall pipeline by 1 cycle: Hold PC & IF/ID, Insert NOP bubble in ID/EX
        Freeze(PC)
        Freeze(IF_ID_Register)
        ID_EX_Register = NOP
    END IF
END PROCEDURE

// -------------------------------------------------------------------------
// 5. DYNAMIC 2-BIT SATURATING BRANCH PREDICTION FSM
// -------------------------------------------------------------------------
FUNCTION PredictBranch(CurrentState, ActualOutcome):
    Prediction = (CurrentState == "10" OR CurrentState == "11") ? TAKEN : NOT_TAKEN
    
    // State Transition Logic
    IF ActualOutcome == TAKEN THEN:
        NextState = Min(CurrentState + 1, "11")
    ELSE:
        NextState = Max(CurrentState - 1, "00")
    END IF
    
    IF Prediction != ActualOutcome THEN:
        // Branch Misprediction Flush
        Flush(IF_Stage)
        Flush(ID_Stage)
        PenaltyCycles = 2
    END IF
    RETURN (Prediction, NextState)
END FUNCTION

// -------------------------------------------------------------------------
// 6. PERFORMANCE EVALUATION & ACTUATION
// -------------------------------------------------------------------------
PROCEDURE EvaluateAndActuate(TotalCycles, InstructionCount):
    CPI         = TotalCycles / InstructionCount
    Throughput  = InstructionCount / TotalCycles
    Speedup     = UnoptimizedCycles / OptimizedCycles
    StallReduce = ((UnoptStalls - OptStalls) / UnoptStalls) * 100
    
    // Actuate Solenoid Valve IO
    IF WaterDemand > 0 THEN:
        Write_IO(0x3000, WaterDemand)  // Open Valve (Flow in L/min)
    ELSE:
        Write_IO(0x3000, 0)            // Close Valve
    END IF
END PROCEDURE`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullPseudocode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
              <Code2 className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 tracking-tight">
              System Algorithm & Architectural Pseudocode
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Complete formalized algorithm spanning sensor sampling, Booth multiplication, pipeline forwarding unit, 2-bit FSM, and valve actuation.
          </p>
        </div>

        <button
          id="copy-pseudocode-btn"
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200 transition cursor-pointer self-start md:self-auto shadow-xs"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-600" /> Copied to Clipboard!
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5 text-emerald-700" /> Copy Pseudocode
            </>
          )}
        </button>
      </div>

      {/* Code Editor Container */}
      <div className="rounded-xl bg-white border border-slate-200 shadow-xs overflow-hidden font-mono text-xs">
        <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <span className="text-slate-600 text-xs ml-1 font-bold">
              smart_irrigation_processor_datapath.pseudo
            </span>
          </div>
          <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-bold">
            RISC-V / MIPS Pipelined Architecture Standard
          </span>
        </div>

        <div className="p-4 sm:p-5 overflow-x-auto text-slate-700 leading-relaxed max-h-[550px] overflow-y-auto bg-slate-900 text-slate-100">
          <pre className="text-emerald-400 text-xs whitespace-pre font-mono leading-relaxed">{fullPseudocode}</pre>
        </div>
      </div>
    </div>
  );
};

